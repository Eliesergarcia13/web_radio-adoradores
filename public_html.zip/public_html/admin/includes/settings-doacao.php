<div class="col-md-12">
<br/>
<h2>Doação</h2>
<h5>Olá <?php echo $perfil_nome; ?>, sou seu tutor virtual. Aqui você poderá configurar o sistema de doação.</h5>
<br/>
</div>

<div class="col-md-6">
                     <!--   Basic Table  -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
							Configurações de Doação
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">

<form role="form" action = "index.php?p=settings-doacao" method = "post">

<?php
require_once("login.php");

if ($_POST["status"] == 1) {

     if (isset($_SESSION["token"])
        && isset($_SESSION["token_time"])
        && isset($_POST["token"])
        && $_SESSION["token"] == $_POST["token"]) {

        $timestamp_old = time() - (60*60);

        if ($_SESSION["token_time"] >= $timestamp_old) {

	        foreach ($_POST as $var => $key) {
                $$var = htmlspecialchars(trim(stripslashes($key)), ENT_QUOTES, "UTF-8");
            }

$config_doacao = '<?php
$doacao = "'. $doacao .'";
$email_pagseguro = "'. $email_pagseguro .'";
$msg_doacao = "'. $msg_doacao .'";
?>';

            if ($fp = fopen("bd/doacao.php", "w")) {
                fwrite($fp, $config_doacao, strlen($config_doacao));

                $_SESSION["saved"]=true;
                $host  = $_SERVER['HTTP_HOST'];
				$uri   = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
				header("Location: http://$host$uri/index.php?p=settings-doacao");
				die();

            } else {
                echo "<p class=\"errorMsg\">$lang_settings_unwritable</p>";
            }
        }
    }
}

if (empty($_SESSION["token"]) || $_SESSION["token_time"] <= $timestamp_old){
		 $_SESSION["token"]      = md5(uniqid(rand(), TRUE));
		 $_SESSION["token_time"] = time();
}

if (!isset($_POST["status"])) {
?>


  <div class="form-group">
     <label>Ativar / Desativar</label>
     <select class="form-control" name="doacao">

     <?php
     $doacao_options = array(
        array(Ativar Doação,'1'),
        array(Desativar Doação,'0')
        );

     foreach ($doacao_options as $doacao_option) {

    ?><option value = "<?php echo $doacao_option[1]; ?>"<?php echo $doacao == $doacao_option[1] ? 'selected="selected"' : '';?>><?php echo ucfirst($doacao_option[0]); ?></option><?php
        } ?>
     </select>
  </div>

	<div class="form-group">
	    <label>E-mail PagSeguro</label>
	    <input required class="form-control" type="email" name="email_pagseguro" value="<?php echo $email_pagseguro; ?>" />
      <a href="https://pagseguro.uol.com.br/" target="_blank">Criar uma conta no PagSeguro</a>
	</div>

    <div class="form-group">
      <label>Mensagem</label>
      <input required class="form-control" type="text" name="msg_doacao" value="<?php echo $msg_doacao; ?>" />
  </div>


<div class="form-group">
    <input type="hidden" name="status" value="1" />
    <input type="hidden" name="token" value="<?php echo $_SESSION["token"]; ?>" />
    <button class="btn btn-success" type = "submit"><i class="fa fa-floppy-o"></i> Salvar</button> 
  <?php greenCheckmark();?>
  </div>
    </form>

  

<?php } ?>
</div>
</div>
</div>
</div>

