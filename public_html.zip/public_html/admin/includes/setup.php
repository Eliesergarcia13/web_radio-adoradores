<?PHP
$updatesDataServerUrlPrefix = base64_decode(''); 
#$updatesDataServerUrlPrefix = base64_decode('aHR0cDovL2xvY2FsaG9zdC91cGRhdGUv');
$filenameAllReleaseVersions = base64_decode('');
$directoryAllUpdatePackages = base64_decode('');
$localVersionFile = base64_decode('dmVyc2lvbi50eHQ=');
$localDownloadDir = base64_decode('YWRtaW4vdXBkYXRlcy8=');
$automaticallyScrollToTheBottomOfThePage = true;
