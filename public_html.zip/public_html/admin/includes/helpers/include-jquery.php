<script src="http://<?php echo $_SERVER['HTTP_HOST'] ?>/<?php echo $pulse_dir; ?>/plugins/jquery/jquery.min.js"></script>
