<?php

class read_File_Videos{
	
	function __construct($name){		
		$this->name = $name;	
		
		if($this->name == "videos"){$this->name = ROOTPATH . "/data/videos/videosfile.txt";}
		else if($this->name == "comment"){$this->name = ROOTPATH . "/data/videos/videos.txt";}
		else { echo $lang_blog_error_reading;}			
	 }	

	function getData(){
		$open = fopen($this->name , "r");
		$data = @fread($open, filesize($this->name));
		fclose($open);		
		return $data;		
	}	

	function getLines(){				
		$lines = explode("\n", $this->getData());
		return $lines;
	}
	
	function countLines(){	
		$amount_of_lines = count($this->getLines());
		return $amount_of_lines-1;		
	}	
	
}//end class


class show_Videos{

    function __construct(){	
    	$this->blog_file_1 = new read_File_Videos("videos");
		$this->amount      = $this->blog_file_1->countLines();
		$this->lines       = $this->blog_file_1->getLines();    
	}	
	
	function val_videos($test){
			
		if (isset($test) && strlen($test > 0) && is_numeric($test)) {
			   return true;
		}
	    return false; 
	}	

	function get_blog_video($id_post){
			
		for ($i = 0; $i < $this->amount; $i++) { 
	        $blog = explode("|", $this->lines[$i]);
				 
			if ($blog[0] == $id_post) {
		    	$no_posts_found++;
				$date     = explode( ' ' , $blog[2]);
				$date     = $date[2] . ' ' . $date[1]  . ' ' . $date[3];
				$title    = cleanUrlname($blog[3]);
				$blog_0   = $blog[0];
			
				$blogfile = array($no_posts_found, $blog_0, $date, $title , $blog[4], $blog[1], $blog[3], $blog[5]);			
			}
		}
			return $blogfile;
	}	


	function amount_pages_videos($per_page){
	
		$result_per_page = $per_page ; 
		$total_pages     = ceil($this->amount/$result_per_page);
		$cur_page        = $_GET['page'] ? $_GET['page'] : 1;

		$start = $this->amount - (($cur_page-1) * $result_per_page);
		$end   = $this->amount - (($cur_page) * $result_per_page);
		
		$nums = array($total_pages, $cur_page, $start, $end);

		return $nums;
	}
	
	function get_blog_videos($per_page,$lang_blog_more){

		$nums = $this->amount_pages_videos($per_page);

	    for ($n = $nums[2]-1; $n >= $nums[3]; $n-- ) { 
	    
		    $blog = explode("|", $this->lines[$n]);
		
		    if (isset($blog[0]) && $blog[0] != '') {
			
			    $date    = explode( ' ' , $blog[2]);
			    $date    = $date[2]. ' ' .$date[1] . ' ' .$date[3];
			    $title   = cleanUrlname($blog[3]);
			    $content = $blog[4];
			
			    if (preg_match("/^(.*)##more##/U", $blog[4], $m)) { 
				$content = $m[1] . "<a href='blog-$blog[0]-".cleanUrlname($blog[3])."' class='read-more'>$lang_blog_more</a>\n";
			    } 
			    
			    $blogposts[] = array($blog[0], $blog[1], $date, $title, $content, $blog[3], $blog[4], $blog[2]);
			 }
		}
		return $blogposts;
	}

		
}	
	
class add_Content_Videos{

		function __construct($name,$data){		
		$this->name = $name;
		$this->data = $data;	
		
		if($this->name == "videos"){$this->name = ROOTPATH . "/data/videos/videosfile.txt";}
		else if($this->name == "comment"){$this->name = ROOTPATH . "/data/videos/comments.txt";}
		else { echo $lang_blog_error_reading;}
		}
		
		function appendData(){
			$open = fopen($this->name, "a");
			fwrite($open, $this->data);
			fclose($open);
		}
		
		function writeData(){			
			$open = fopen($this->name, "w");
			fwrite($open, $this->data);
			fclose($open);			
		}	
				
				
}//end class


//sanatize input
function super_clean_videos($text){	
	$text = trim(stripslashes(strip_tags(htmlspecialchars($text, ENT_QUOTES, 'UTF-8'))));	
	return $text;
}

?>