<div class="col-md-12">
<br/>
<h2>Streaming</h2>
<h5>Olá <?php echo $perfil_nome; ?>, sou seu tutor virtual. Aqui você poderá cadastrar seu canal de streaming.</h5>
<br/>
</div>

<div class="col-md-6">
                     <!--   Basic Table  -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
							Configurações Streaming
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">

<form role="form" action = "index.php?p=settings-stream" method = "post">

<?php
require_once("login.php");

if ($_POST["status"] == 1) {

     if (isset($_SESSION["token"])
        && isset($_SESSION["token_time"])
        && isset($_POST["token"])
        && $_SESSION["token"] == $_POST["token"]) {

        $timestamp_old = time() - (60*60);

        if ($_SESSION["token_time"] >= $timestamp_old) {

	        foreach ($_POST as $var => $key) {
                $$var = htmlspecialchars(trim(stripslashes($key)), ENT_QUOTES, "UTF-8");
            }

$config_stream = '<?php
$ip_stream = "'. $ip_stream .'";
$port_stream = "'. $port_stream .'";
$prot_stream = "'. $prot_stream .'";

?>';

            if ($fp = fopen("bd/stream.php", "w")) {
                fwrite($fp, $config_stream, strlen($config_stream));

                $_SESSION["saved"]=true;
                $host  = $_SERVER['HTTP_HOST'];
				$uri   = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
				header("Location: http://$host$uri/index.php?p=settings-stream");
				die();

            } else {
                echo "<p class=\"errorMsg\">$lang_settings_unwritable</p>";
            }
        }
    }
}

if (empty($_SESSION["token"]) || $_SESSION["token_time"] <= $timestamp_old){
		 $_SESSION["token"]      = md5(uniqid(rand(), TRUE));
		 $_SESSION["token_time"] = time();
}

if (!isset($_POST["status"])) {
?>

	<div class="form-group">
	    <label>Ip</label>
	    <input class="form-control" type="text" name="ip_stream" value="<?php echo $ip_stream; ?>" />
	</div>

	<div class="form-group">
	    <label>Porta</label>
	    <input class="form-control" type="text" name="port_stream" value="<?php echo $port_stream; ?>" />
	</div>

	<div class="form-group">
	   <label>Protocolo</label>
	   <select class="form-control" name="prot_stream">

	   <?php
	   $prot_stream_options = array(
	      array(SHOUTcast,'/stream'),
	   		array(Icecast,'/live')
	   		);

	   foreach ($prot_stream_options as $prot_stream_option) {

		?><option value = "<?php echo $prot_stream_option[1]; ?>"<?php echo $prot_stream == $prot_stream_option[1] ? 'selected="selected"' : '';?>><?php echo ucfirst($prot_stream_option[0]); ?></option><?php
			  } ?>
	   </select>
	</div>

    <input type="hidden" name="status" value="1" />
    <input type="hidden" name="token" value="<?php echo $_SESSION["token"]; ?>" />
    <button class="btn btn-success" type = "submit"><i class="fa fa-floppy-o"></i> Salvar</button> 
  <?php greenCheckmark();?>
    </form>

  

<?php } ?>
</div>
</div>
</div>
</div>

