<link rel="stylesheet" href="assets/css/tabs.css">
<div class="col-md-12">
<br/>
<h2>Programação</h2>
<h5>Olá <?php echo $perfil_nome; ?>, sou seu tutor virtual. Aqui você poderá cadastrar a programação da rádio.</h5>
<br/>
</div>

<form role="form" action = "index.php?p=settings-programacao" method = "post">

<?php

require_once("login.php");

if ($_POST["status"] == 1) {

     if (isset($_SESSION["token"])
        && isset($_SESSION["token_time"])
        && isset($_POST["token"])
        && $_SESSION["token"] == $_POST["token"]) {

        $timestamp_old = time() - (60*60);

        if ($_SESSION["token_time"] >= $timestamp_old) {

	        foreach ($_POST as $var => $key) {
                $$var = htmlspecialchars(trim(stripslashes($key)), ENT_QUOTES, "UTF-8");
            }

$config_programacao = '<?php
$seg_h1 = "'. $seg_h1 .'";
$seg_h2 = "'. $seg_h2 .'";
$seg_h3 = "'. $seg_h3 .'";
$seg_h4 = "'. $seg_h4 .'";
$seg_h5 = "'. $seg_h5 .'";
$seg_h6 = "'. $seg_h6 .'";
$seg_h7 = "'. $seg_h7 .'";
$seg_h8 = "'. $seg_h8 .'";
$seg_h9 = "'. $seg_h9.'";
$seg_h10 = "'. $seg_h10 .'";
$seg_p1 = "'. $seg_p1 .'";
$seg_p2 = "'. $seg_p2 .'";
$seg_p3 = "'. $seg_p3 .'";
$seg_p4 = "'. $seg_p4 .'";
$seg_p5 = "'. $seg_p5 .'";
$seg_p6 = "'. $seg_p6 .'";
$seg_p7 = "'. $seg_p7 .'";
$seg_p8 = "'. $seg_p8 .'";
$seg_p9 = "'. $seg_p9.'";
$seg_p10 = "'. $seg_p10 .'";
$seg_a1 = "'. $seg_a1 .'";
$seg_a2 = "'. $seg_a2 .'";
$seg_a3 = "'. $seg_a3 .'";
$seg_a4 = "'. $seg_a4 .'";
$seg_a5 = "'. $seg_a5 .'";
$seg_a6 = "'. $seg_a6 .'";
$seg_a7 = "'. $seg_a7 .'";
$seg_a8 = "'. $seg_a8 .'";
$seg_a9 = "'. $seg_a9.'";
$seg_a10 = "'. $seg_a10 .'";

$ter_h1 = "'. $ter_h1 .'";
$ter_h2 = "'. $ter_h2 .'";
$ter_h3 = "'. $ter_h3 .'";
$ter_h4 = "'. $ter_h4 .'";
$ter_h5 = "'. $ter_h5 .'";
$ter_h6 = "'. $ter_h6 .'";
$ter_h7 = "'. $ter_h7 .'";
$ter_h8 = "'. $ter_h8 .'";
$ter_h9 = "'. $ter_h9.'";
$ter_h10 = "'. $ter_h10 .'";
$ter_p1 = "'. $ter_p1 .'";
$ter_p2 = "'. $ter_p2 .'";
$ter_p3 = "'. $ter_p3 .'";
$ter_p4 = "'. $ter_p4 .'";
$ter_p5 = "'. $ter_p5 .'";
$ter_p6 = "'. $ter_p6 .'";
$ter_p7 = "'. $ter_p7 .'";
$ter_p8 = "'. $ter_p8 .'";
$ter_p9 = "'. $ter_p9.'";
$ter_p10 = "'. $ter_p10 .'";
$ter_a1 = "'. $ter_a1 .'";
$ter_a2 = "'. $ter_a2 .'";
$ter_a3 = "'. $ter_a3 .'";
$ter_a4 = "'. $ter_a4 .'";
$ter_a5 = "'. $ter_a5 .'";
$ter_a6 = "'. $ter_a6 .'";
$ter_a7 = "'. $ter_a7 .'";
$ter_a8 = "'. $ter_a8 .'";
$ter_a9 = "'. $ter_a9.'";
$ter_a10 = "'. $ter_a10 .'";

$qua_h1 = "'. $qua_h1 .'";
$qua_h2 = "'. $qua_h2 .'";
$qua_h3 = "'. $qua_h3 .'";
$qua_h4 = "'. $qua_h4 .'";
$qua_h5 = "'. $qua_h5 .'";
$qua_h6 = "'. $qua_h6 .'";
$qua_h7 = "'. $qua_h7 .'";
$qua_h8 = "'. $qua_h8 .'";
$qua_h9 = "'. $qua_h9.'";
$qua_h10 = "'. $qua_h10 .'";
$qua_p1 = "'. $qua_p1 .'";
$qua_p2 = "'. $qua_p2 .'";
$qua_p3 = "'. $qua_p3 .'";
$qua_p4 = "'. $qua_p4 .'";
$qua_p5 = "'. $qua_p5 .'";
$qua_p6 = "'. $qua_p6 .'";
$qua_p7 = "'. $qua_p7 .'";
$qua_p8 = "'. $qua_p8 .'";
$qua_p9 = "'. $qua_p9.'";
$qua_p10 = "'. $qua_p10 .'";
$qua_a1 = "'. $qua_a1 .'";
$qua_a2 = "'. $qua_a2 .'";
$qua_a3 = "'. $qua_a3 .'";
$qua_a4 = "'. $qua_a4 .'";
$qua_a5 = "'. $qua_a5 .'";
$qua_a6 = "'. $qua_a6 .'";
$qua_a7 = "'. $qua_a7 .'";
$qua_a8 = "'. $qua_a8 .'";
$qua_a9 = "'. $qua_a9.'";
$qua_a10 = "'. $qua_a10 .'";

$qui_h1 = "'. $qui_h1 .'";
$qui_h2 = "'. $qui_h2 .'";
$qui_h3 = "'. $qui_h3 .'";
$qui_h4 = "'. $qui_h4 .'";
$qui_h5 = "'. $qui_h5 .'";
$qui_h6 = "'. $qui_h6 .'";
$qui_h7 = "'. $qui_h7 .'";
$qui_h8 = "'. $qui_h8 .'";
$qui_h9 = "'. $qui_h9.'";
$qui_h10 = "'. $qui_h10 .'";
$qui_p1 = "'. $qui_p1 .'";
$qui_p2 = "'. $qui_p2 .'";
$qui_p3 = "'. $qui_p3 .'";
$qui_p4 = "'. $qui_p4 .'";
$qui_p5 = "'. $qui_p5 .'";
$qui_p6 = "'. $qui_p6 .'";
$qui_p7 = "'. $qui_p7 .'";
$qui_p8 = "'. $qui_p8 .'";
$qui_p9 = "'. $qui_p9.'";
$qui_p10 = "'. $qui_p10 .'";
$qui_a1 = "'. $qui_a1 .'";
$qui_a2 = "'. $qui_a2 .'";
$qui_a3 = "'. $qui_a3 .'";
$qui_a4 = "'. $qui_a4 .'";
$qui_a5 = "'. $qui_a5 .'";
$qui_a6 = "'. $qui_a6 .'";
$qui_a7 = "'. $qui_a7 .'";
$qui_a8 = "'. $qui_a8 .'";
$qui_a9 = "'. $qui_a9.'";
$qui_a10 = "'. $qui_a10 .'";

$sex_h1 = "'. $sex_h1 .'";
$sex_h2 = "'. $sex_h2 .'";
$sex_h3 = "'. $sex_h3 .'";
$sex_h4 = "'. $sex_h4 .'";
$sex_h5 = "'. $sex_h5 .'";
$sex_h6 = "'. $sex_h6 .'";
$sex_h7 = "'. $sex_h7 .'";
$sex_h8 = "'. $sex_h8 .'";
$sex_h9 = "'. $sex_h9.'";
$sex_h10 = "'. $sex_h10 .'";
$sex_p1 = "'. $sex_p1 .'";
$sex_p2 = "'. $sex_p2 .'";
$sex_p3 = "'. $sex_p3 .'";
$sex_p4 = "'. $sex_p4 .'";
$sex_p5 = "'. $sex_p5 .'";
$sex_p6 = "'. $sex_p6 .'";
$sex_p7 = "'. $sex_p7 .'";
$sex_p8 = "'. $sex_p8 .'";
$sex_p9 = "'. $sex_p9.'";
$sex_p10 = "'. $sex_p10 .'";
$sex_a1 = "'. $sex_a1 .'";
$sex_a2 = "'. $sex_a2 .'";
$sex_a3 = "'. $sex_a3 .'";
$sex_a4 = "'. $sex_a4 .'";
$sex_a5 = "'. $sex_a5 .'";
$sex_a6 = "'. $sex_a6 .'";
$sex_a7 = "'. $sex_a7 .'";
$sex_a8 = "'. $sex_a8 .'";
$sex_a9 = "'. $sex_a9.'";
$sex_a10 = "'. $sex_a10 .'";

$sab_h1 = "'. $sab_h1 .'";
$sab_h2 = "'. $sab_h2 .'";
$sab_h3 = "'. $sab_h3 .'";
$sab_h4 = "'. $sab_h4 .'";
$sab_h5 = "'. $sab_h5 .'";
$sab_h6 = "'. $sab_h6 .'";
$sab_h7 = "'. $sab_h7 .'";
$sab_h8 = "'. $sab_h8 .'";
$sab_h9 = "'. $sab_h9.'";
$sab_h10 = "'. $sab_h10 .'";
$sab_p1 = "'. $sab_p1 .'";
$sab_p2 = "'. $sab_p2 .'";
$sab_p3 = "'. $sab_p3 .'";
$sab_p4 = "'. $sab_p4 .'";
$sab_p5 = "'. $sab_p5 .'";
$sab_p6 = "'. $sab_p6 .'";
$sab_p7 = "'. $sab_p7 .'";
$sab_p8 = "'. $sab_p8 .'";
$sab_p9 = "'. $sab_p9.'";
$sab_p10 = "'. $sab_p10 .'";
$sab_a1 = "'. $sab_a1 .'";
$sab_a2 = "'. $sab_a2 .'";
$sab_a3 = "'. $sab_a3 .'";
$sab_a4 = "'. $sab_a4 .'";
$sab_a5 = "'. $sab_a5 .'";
$sab_a6 = "'. $sab_a6 .'";
$sab_a7 = "'. $sab_a7 .'";
$sab_a8 = "'. $sab_a8 .'";
$sab_a9 = "'. $sab_a9.'";
$sab_a10 = "'. $sab_a10 .'";

$dom_h1 = "'. $dom_h1 .'";
$dom_h2 = "'. $dom_h2 .'";
$dom_h3 = "'. $dom_h3 .'";
$dom_h4 = "'. $dom_h4 .'";
$dom_h5 = "'. $dom_h5 .'";
$dom_h6 = "'. $dom_h6 .'";
$dom_h7 = "'. $dom_h7 .'";
$dom_h8 = "'. $dom_h8 .'";
$dom_h9 = "'. $dom_h9.'";
$dom_h10 = "'. $dom_h10 .'";
$dom_p1 = "'. $dom_p1 .'";
$dom_p2 = "'. $dom_p2 .'";
$dom_p3 = "'. $dom_p3 .'";
$dom_p4 = "'. $dom_p4 .'";
$dom_p5 = "'. $dom_p5 .'";
$dom_p6 = "'. $dom_p6 .'";
$dom_p7 = "'. $dom_p7 .'";
$dom_p8 = "'. $dom_p8 .'";
$dom_p9 = "'. $dom_p9.'";
$dom_p10 = "'. $dom_p10 .'";
$dom_a1 = "'. $dom_a1 .'";
$dom_a2 = "'. $dom_a2 .'";
$dom_a3 = "'. $dom_a3 .'";
$dom_a4 = "'. $dom_a4 .'";
$dom_a5 = "'. $dom_a5 .'";
$dom_a6 = "'. $dom_a6 .'";
$dom_a7 = "'. $dom_a7 .'";
$dom_a8 = "'. $dom_a8 .'";
$dom_a9 = "'. $dom_a9.'";
$dom_a10 = "'. $dom_a10 .'";

?>';

            if ($fp = fopen("bd/programacao.php", "w")) {
                fwrite($fp, $config_programacao, strlen($config_programacao));

                $_SESSION["saved"]=true;
                $host  = $_SERVER['HTTP_HOST'];
				$uri   = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
				header("Location: http://$host$uri/index.php?p=settings-programacao");
				die();

            } else {
                echo "<p class=\"errorMsg\">$lang_settings_unwritable</p>";
            }
        }
    }
}

if (empty($_SESSION["token"]) || $_SESSION["token_time"] <= $timestamp_old){
		 $_SESSION["token"]      = md5(uniqid(rand(), TRUE));
		 $_SESSION["token_time"] = time();
}

if (!isset($_POST["status"])) {
?>



<ul class="nav nav-tabs">
  <li class="active"><a data-toggle="tab" href="#seg">Segunda</a></li>
  <li><a data-toggle="tab" href="#ter">Terça</a></li>
  <li><a data-toggle="tab" href="#qua">Quarta</a></li>
  <li><a data-toggle="tab" href="#qui">Quinta</a></li>
  <li><a data-toggle="tab" href="#sex">Sexta</a></li>
  <li><a data-toggle="tab" href="#sab">Sábado</a></li>
  <li><a data-toggle="tab" href="#dom">Domingo</a></li>
  
</ul>


<div class="tab-content">

<div id="seg" class="tab-pane fade in active">
<br/>
<div class="col-md-6">
                     <!--   Basic Table  -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
							Segunda-feira
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">

         
	<div class="form-group">


 <table>
    <thead>
      <tr>
        <th>Horário</th>
        <th>Programa</th>
        <th>Apresentador</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td><input class="form-control" type="text" name="seg_h1" value="<?php echo $seg_h1; ?>" /></td>
        <td><input class="form-control" type="text" name="seg_p1" value="<?php echo $seg_p1; ?>" /></td>
        <td><input class="form-control" type="text" name="seg_a1" value="<?php echo $seg_a1; ?>" /></td>
      </tr>
      <tr>
        <td><input class="form-control" type="text" name="seg_h2" value="<?php echo $seg_h2; ?>" /></td>
        <td><input class="form-control" type="text" name="seg_p2" value="<?php echo $seg_p2; ?>" /></td>
        <td><input class="form-control" type="text" name="seg_a2" value="<?php echo $seg_a2; ?>" /></td>
      </tr>
      <tr>
        <td><input class="form-control" type="text" name="seg_h3" value="<?php echo $seg_h3; ?>" /></td>
        <td><input class="form-control" type="text" name="seg_p3" value="<?php echo $seg_p3; ?>" /></td>
        <td><input class="form-control" type="text" name="seg_a3" value="<?php echo $seg_a3; ?>" /></td>
      </tr>
            <tr>
        <td><input class="form-control" type="text" name="seg_h4" value="<?php echo $seg_h4; ?>" /></td>
        <td><input class="form-control" type="text" name="seg_p4" value="<?php echo $seg_p4; ?>" /></td>
        <td><input class="form-control" type="text" name="seg_a4" value="<?php echo $seg_a4; ?>" /></td>
      </tr>
            <tr>
        <td><input class="form-control" type="text" name="seg_h5" value="<?php echo $seg_h5; ?>" /></td>
        <td><input class="form-control" type="text" name="seg_p5" value="<?php echo $seg_p5; ?>" /></td>
        <td><input class="form-control" type="text" name="seg_a5" value="<?php echo $seg_a5; ?>" /></td>
      </tr>
            <tr>
        <td><input class="form-control" type="text" name="seg_h6" value="<?php echo $seg_h6; ?>" /></td>
        <td><input class="form-control" type="text" name="seg_p6" value="<?php echo $seg_p6; ?>" /></td>
        <td><input class="form-control" type="text" name="seg_a6" value="<?php echo $seg_a6; ?>" /></td>
      </tr>
      <tr>
        <td><input class="form-control" type="text" name="seg_h7" value="<?php echo $seg_h7; ?>" /></td>
        <td><input class="form-control" type="text" name="seg_p7" value="<?php echo $seg_p7; ?>" /></td>
        <td><input class="form-control" type="text" name="seg_a7" value="<?php echo $seg_a7; ?>" /></td>
      </tr>
      <tr>
        <td><input class="form-control" type="text" name="seg_h8" value="<?php echo $seg_h8; ?>" /></td>
        <td><input class="form-control" type="text" name="seg_p8" value="<?php echo $seg_p8; ?>" /></td>
        <td><input class="form-control" type="text" name="seg_a8" value="<?php echo $seg_a8; ?>" /></td>
      </tr>
            <tr>
        <td><input class="form-control" type="text" name="seg_h9" value="<?php echo $seg_h9; ?>" /></td>
        <td><input class="form-control" type="text" name="seg_p9" value="<?php echo $seg_p9; ?>" /></td>
        <td><input class="form-control" type="text" name="seg_a9" value="<?php echo $seg_a9; ?>" /></td>
      </tr>
      <tr>
        <td><input class="form-control" type="text" name="seg_h10" value="<?php echo $seg_h10; ?>" /></td>
        <td><input class="form-control" type="text" name="seg_p10" value="<?php echo $seg_p10; ?>" /></td>
        <td><input class="form-control" type="text" name="seg_a10" value="<?php echo $seg_a10; ?>" /></td>
      </tr>
    </tbody>
  </table>
</div>

    <input type="hidden" name="status" value="1" />
    <input type="hidden" name="token" value="<?php echo $_SESSION["token"]; ?>" />
    <button class="btn btn-success" type = "submit"><i class="fa fa-floppy-o"></i> Salvar</button>
</div>
</div>
</div>
</div>
</div>

  <div id="ter" class="tab-pane fade">
<br/>
<div class="col-md-6">
                     <!--   Basic Table  -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
              Terça-feira
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">

         
  <div class="form-group">

  <table>
    <thead>
      <tr>
        <th>Horário</th>
        <th>Programa</th>
        <th>Apresentador</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td><input class="form-control" type="text" name="ter_h1" value="<?php echo $ter_h1; ?>" /></td>
        <td><input class="form-control" type="text" name="ter_p1" value="<?php echo $ter_p1; ?>" /></td>
        <td><input class="form-control" type="text" name="ter_a1" value="<?php echo $ter_a1; ?>" /></td>
      </tr>
      <tr>
        <td><input class="form-control" type="text" name="ter_h2" value="<?php echo $ter_h2; ?>" /></td>
        <td><input class="form-control" type="text" name="ter_p2" value="<?php echo $ter_p2; ?>" /></td>
        <td><input class="form-control" type="text" name="ter_a2" value="<?php echo $ter_a2; ?>" /></td>
      </tr>
      <tr>
        <td><input class="form-control" type="text" name="ter_h3" value="<?php echo $ter_h3; ?>" /></td>
        <td><input class="form-control" type="text" name="ter_p3" value="<?php echo $ter_p3; ?>" /></td>
        <td><input class="form-control" type="text" name="ter_a3" value="<?php echo $ter_a3; ?>" /></td>
      </tr>
            <tr>
        <td><input class="form-control" type="text" name="ter_h4" value="<?php echo $ter_h4; ?>" /></td>
        <td><input class="form-control" type="text" name="ter_p4" value="<?php echo $ter_p4; ?>" /></td>
        <td><input class="form-control" type="text" name="ter_a4" value="<?php echo $ter_a4; ?>" /></td>
      </tr>
            <tr>
        <td><input class="form-control" type="text" name="ter_h5" value="<?php echo $ter_h5; ?>" /></td>
        <td><input class="form-control" type="text" name="ter_p5" value="<?php echo $ter_p5; ?>" /></td>
        <td><input class="form-control" type="text" name="ter_a5" value="<?php echo $ter_a5; ?>" /></td>
      </tr>
            <tr>
        <td><input class="form-control" type="text" name="ter_h6" value="<?php echo $ter_h6; ?>" /></td>
        <td><input class="form-control" type="text" name="ter_p6" value="<?php echo $ter_p6; ?>" /></td>
        <td><input class="form-control" type="text" name="ter_a6" value="<?php echo $ter_a6; ?>" /></td>
      </tr>
      <tr>
        <td><input class="form-control" type="text" name="ter_h7" value="<?php echo $ter_h7; ?>" /></td>
        <td><input class="form-control" type="text" name="ter_p7" value="<?php echo $ter_p7; ?>" /></td>
        <td><input class="form-control" type="text" name="ter_a7" value="<?php echo $ter_a7; ?>" /></td>
      </tr>
      <tr>
        <td><input class="form-control" type="text" name="ter_h8" value="<?php echo $ter_h8; ?>" /></td>
        <td><input class="form-control" type="text" name="ter_p8" value="<?php echo $ter_p8; ?>" /></td>
        <td><input class="form-control" type="text" name="ter_a8" value="<?php echo $ter_a8; ?>" /></td>
      </tr>
            <tr>
        <td><input class="form-control" type="text" name="ter_h9" value="<?php echo $ter_h9; ?>" /></td>
        <td><input class="form-control" type="text" name="ter_p9" value="<?php echo $ter_p9; ?>" /></td>
        <td><input class="form-control" type="text" name="ter_a9" value="<?php echo $ter_a9; ?>" /></td>
      </tr>
      <tr>
        <td><input class="form-control" type="text" name="ter_h10" value="<?php echo $ter_h10; ?>" /></td>
        <td><input class="form-control" type="text" name="ter_p10" value="<?php echo $ter_p10; ?>" /></td>
        <td><input class="form-control" type="text" name="ter_a10" value="<?php echo $ter_a10; ?>" /></td>
      </tr>
    </tbody>
  </table>
</div>
    <button class="btn btn-success" type = "submit"><i class="fa fa-floppy-o"></i> Salvar</button>
</div>
</div>
</div>
</div>
</div>
  <div id="qua" class="tab-pane fade">
<br/>
<div class="col-md-6">
                     <!--   Basic Table  -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
              Quarta-feira
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">

         
  <div class="form-group">
 <table>
    <thead>
      <tr>
        <th>Horário</th>
        <th>Programa</th>
        <th>Apresentador</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td><input class="form-control" type="text" name="qua_h1" value="<?php echo $qua_h1; ?>" /></td>
        <td><input class="form-control" type="text" name="qua_p1" value="<?php echo $qua_p1; ?>" /></td>
        <td><input class="form-control" type="text" name="qua_a1" value="<?php echo $qua_a1; ?>" /></td>
      </tr>
      <tr>
        <td><input class="form-control" type="text" name="qua_h2" value="<?php echo $qua_h2; ?>" /></td>
        <td><input class="form-control" type="text" name="qua_p2" value="<?php echo $qua_p2; ?>" /></td>
        <td><input class="form-control" type="text" name="qua_a2" value="<?php echo $qua_a2; ?>" /></td>
      </tr>
      <tr>
        <td><input class="form-control" type="text" name="qua_h3" value="<?php echo $qua_h3; ?>" /></td>
        <td><input class="form-control" type="text" name="qua_p3" value="<?php echo $qua_p3; ?>" /></td>
        <td><input class="form-control" type="text" name="qua_a3" value="<?php echo $qua_a3; ?>" /></td>
      </tr>
            <tr>
        <td><input class="form-control" type="text" name="qua_h4" value="<?php echo $qua_h4; ?>" /></td>
        <td><input class="form-control" type="text" name="qua_p4" value="<?php echo $qua_p4; ?>" /></td>
        <td><input class="form-control" type="text" name="qua_a4" value="<?php echo $qua_a4; ?>" /></td>
      </tr>
            <tr>
        <td><input class="form-control" type="text" name="qua_h5" value="<?php echo $qua_h5; ?>" /></td>
        <td><input class="form-control" type="text" name="qua_p5" value="<?php echo $qua_p5; ?>" /></td>
        <td><input class="form-control" type="text" name="qua_a5" value="<?php echo $qua_a5; ?>" /></td>
      </tr>
            <tr>
        <td><input class="form-control" type="text" name="qua_h6" value="<?php echo $qua_h6; ?>" /></td>
        <td><input class="form-control" type="text" name="qua_p6" value="<?php echo $qua_p6; ?>" /></td>
        <td><input class="form-control" type="text" name="qua_a6" value="<?php echo $qua_a6; ?>" /></td>
      </tr>
      <tr>
        <td><input class="form-control" type="text" name="qua_h7" value="<?php echo $qua_h7; ?>" /></td>
        <td><input class="form-control" type="text" name="qua_p7" value="<?php echo $qua_p7; ?>" /></td>
        <td><input class="form-control" type="text" name="qua_a7" value="<?php echo $qua_a7; ?>" /></td>
      </tr>
      <tr>
        <td><input class="form-control" type="text" name="qua_h8" value="<?php echo $qua_h8; ?>" /></td>
        <td><input class="form-control" type="text" name="qua_p8" value="<?php echo $qua_p8; ?>" /></td>
        <td><input class="form-control" type="text" name="qua_a8" value="<?php echo $qua_a8; ?>" /></td>
      </tr>
            <tr>
        <td><input class="form-control" type="text" name="qua_h9" value="<?php echo $qua_h9; ?>" /></td>
        <td><input class="form-control" type="text" name="qua_p9" value="<?php echo $qua_p9; ?>" /></td>
        <td><input class="form-control" type="text" name="qua_a9" value="<?php echo $qua_a9; ?>" /></td>
      </tr>
      <tr>
        <td><input class="form-control" type="text" name="qua_h10" value="<?php echo $qua_h10; ?>" /></td>
        <td><input class="form-control" type="text" name="qua_p10" value="<?php echo $qua_p10; ?>" /></td>
        <td><input class="form-control" type="text" name="qua_a10" value="<?php echo $qua_a10; ?>" /></td>
      </tr>
    </tbody>
  </table>
</div>

    <button class="btn btn-success" type = "submit"><i class="fa fa-floppy-o"></i> Salvar</button>
</div>
</div>
</div>
</div>
</div>

  <div id="qui" class="tab-pane fade">
<br/>
<div class="col-md-6">
                     <!--   Basic Table  -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
              Quinta-feira
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">

         
  <div class="form-group">
 <table>
    <thead>
      <tr>
        <th>Horário</th>
        <th>Programa</th>
        <th>Apresentador</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td><input class="form-control" type="text" name="qui_h1" value="<?php echo $qui_h1; ?>" /></td>
        <td><input class="form-control" type="text" name="qui_p1" value="<?php echo $qui_p1; ?>" /></td>
        <td><input class="form-control" type="text" name="qui_a1" value="<?php echo $qui_a1; ?>" /></td>
      </tr>
      <tr>
        <td><input class="form-control" type="text" name="qui_h2" value="<?php echo $qui_h2; ?>" /></td>
        <td><input class="form-control" type="text" name="qui_p2" value="<?php echo $qui_p2; ?>" /></td>
        <td><input class="form-control" type="text" name="qui_a2" value="<?php echo $qui_a2; ?>" /></td>
      </tr>
      <tr>
        <td><input class="form-control" type="text" name="qui_h3" value="<?php echo $qui_h3; ?>" /></td>
        <td><input class="form-control" type="text" name="qui_p3" value="<?php echo $qui_p3; ?>" /></td>
        <td><input class="form-control" type="text" name="qui_a3" value="<?php echo $qui_a3; ?>" /></td>
      </tr>
            <tr>
        <td><input class="form-control" type="text" name="qui_h4" value="<?php echo $qui_h4; ?>" /></td>
        <td><input class="form-control" type="text" name="qui_p4" value="<?php echo $qui_p4; ?>" /></td>
        <td><input class="form-control" type="text" name="qui_a4" value="<?php echo $qui_a4; ?>" /></td>
      </tr>
            <tr>
        <td><input class="form-control" type="text" name="qui_h5" value="<?php echo $qui_h5; ?>" /></td>
        <td><input class="form-control" type="text" name="qui_p5" value="<?php echo $qui_p5; ?>" /></td>
        <td><input class="form-control" type="text" name="qui_a5" value="<?php echo $qui_a5; ?>" /></td>
      </tr>
            <tr>
        <td><input class="form-control" type="text" name="qui_h6" value="<?php echo $qui_h6; ?>" /></td>
        <td><input class="form-control" type="text" name="qui_p6" value="<?php echo $qui_p6; ?>" /></td>
        <td><input class="form-control" type="text" name="qui_a6" value="<?php echo $qui_a6; ?>" /></td>
      </tr>
      <tr>
        <td><input class="form-control" type="text" name="qui_h7" value="<?php echo $qui_h7; ?>" /></td>
        <td><input class="form-control" type="text" name="qui_p7" value="<?php echo $qui_p7; ?>" /></td>
        <td><input class="form-control" type="text" name="qui_a7" value="<?php echo $qui_a7; ?>" /></td>
      </tr>
      <tr>
        <td><input class="form-control" type="text" name="qui_h8" value="<?php echo $qui_h8; ?>" /></td>
        <td><input class="form-control" type="text" name="qui_p8" value="<?php echo $qui_p8; ?>" /></td>
        <td><input class="form-control" type="text" name="qui_a8" value="<?php echo $qui_a8; ?>" /></td>
      </tr>
            <tr>
        <td><input class="form-control" type="text" name="qui_h9" value="<?php echo $qui_h9; ?>" /></td>
        <td><input class="form-control" type="text" name="qui_p9" value="<?php echo $qui_p9; ?>" /></td>
        <td><input class="form-control" type="text" name="qui_a9" value="<?php echo $qui_a9; ?>" /></td>
      </tr>
      <tr>
        <td><input class="form-control" type="text" name="qui_h10" value="<?php echo $qui_h10; ?>" /></td>
        <td><input class="form-control" type="text" name="qui_p10" value="<?php echo $qui_p10; ?>" /></td>
        <td><input class="form-control" type="text" name="qui_a10" value="<?php echo $qui_a10; ?>" /></td>
      </tr>
    </tbody>
  </table>
</div>



    <button class="btn btn-success" type = "submit"><i class="fa fa-floppy-o"></i> Salvar</button>
</div>
</div>
</div>
</div>
</div>

  <div id="sex" class="tab-pane fade">
<br/>
<div class="col-md-6">
                     <!--   Basic Table  -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
              Sexta-feira
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">

         
  <div class="form-group">
 <table>
    <thead>
      <tr>
        <th>Horário</th>
        <th>Programa</th>
        <th>Apresentador</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td><input class="form-control" type="text" name="sex_h1" value="<?php echo $sex_h1; ?>" /></td>
        <td><input class="form-control" type="text" name="sex_p1" value="<?php echo $sex_p1; ?>" /></td>
        <td><input class="form-control" type="text" name="sex_a1" value="<?php echo $sex_a1; ?>" /></td>
      </tr>
      <tr>
        <td><input class="form-control" type="text" name="sex_h2" value="<?php echo $sex_h2; ?>" /></td>
        <td><input class="form-control" type="text" name="sex_p2" value="<?php echo $sex_p2; ?>" /></td>
        <td><input class="form-control" type="text" name="sex_a2" value="<?php echo $sex_a2; ?>" /></td>
      </tr>
      <tr>
        <td><input class="form-control" type="text" name="sex_h3" value="<?php echo $sex_h3; ?>" /></td>
        <td><input class="form-control" type="text" name="sex_p3" value="<?php echo $sex_p3; ?>" /></td>
        <td><input class="form-control" type="text" name="sex_a3" value="<?php echo $sex_a3; ?>" /></td>
      </tr>
            <tr>
        <td><input class="form-control" type="text" name="sex_h4" value="<?php echo $sex_h4; ?>" /></td>
        <td><input class="form-control" type="text" name="sex_p4" value="<?php echo $sex_p4; ?>" /></td>
        <td><input class="form-control" type="text" name="sex_a4" value="<?php echo $sex_a4; ?>" /></td>
      </tr>
            <tr>
        <td><input class="form-control" type="text" name="sex_h5" value="<?php echo $sex_h5; ?>" /></td>
        <td><input class="form-control" type="text" name="sex_p5" value="<?php echo $sex_p5; ?>" /></td>
        <td><input class="form-control" type="text" name="sex_a5" value="<?php echo $sex_a5; ?>" /></td>
      </tr>
            <tr>
        <td><input class="form-control" type="text" name="sex_h6" value="<?php echo $sex_h6; ?>" /></td>
        <td><input class="form-control" type="text" name="sex_p6" value="<?php echo $sex_p6; ?>" /></td>
        <td><input class="form-control" type="text" name="sex_a6" value="<?php echo $sex_a6; ?>" /></td>
      </tr>
      <tr>
        <td><input class="form-control" type="text" name="sex_h7" value="<?php echo $sex_h7; ?>" /></td>
        <td><input class="form-control" type="text" name="sex_p7" value="<?php echo $sex_p7; ?>" /></td>
        <td><input class="form-control" type="text" name="sex_a7" value="<?php echo $sex_a7; ?>" /></td>
      </tr>
      <tr>
        <td><input class="form-control" type="text" name="sex_h8" value="<?php echo $sex_h8; ?>" /></td>
        <td><input class="form-control" type="text" name="sex_p8" value="<?php echo $sex_p8; ?>" /></td>
        <td><input class="form-control" type="text" name="sex_a8" value="<?php echo $sex_a8; ?>" /></td>
      </tr>
            <tr>
        <td><input class="form-control" type="text" name="sex_h9" value="<?php echo $sex_h9; ?>" /></td>
        <td><input class="form-control" type="text" name="sex_p9" value="<?php echo $sex_p9; ?>" /></td>
        <td><input class="form-control" type="text" name="sex_a9" value="<?php echo $sex_a9; ?>" /></td>
      </tr>
      <tr>
        <td><input class="form-control" type="text" name="sex_h10" value="<?php echo $sex_h10; ?>" /></td>
        <td><input class="form-control" type="text" name="sex_p10" value="<?php echo $sex_p10; ?>" /></td>
        <td><input class="form-control" type="text" name="sex_a10" value="<?php echo $sex_a10; ?>" /></td>
      </tr>
    </tbody>
  </table>
</div>

    <button class="btn btn-success" type = "submit"><i class="fa fa-floppy-o"></i> Salvar</button>
</div>
</div>
</div>
</div>
</div>

  <div id="sab" class="tab-pane fade">
<br/>
<div class="col-md-6">

                     <!--   Basic Table  -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
              Sábado
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">

         
  <div class="form-group">
 <table>
    <thead>
      <tr>
        <th>Horário</th>
        <th>Programa</th>
        <th>Apresentador</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td><input class="form-control" type="text" name="sab_h1" value="<?php echo $sab_h1; ?>" /></td>
        <td><input class="form-control" type="text" name="sab_p1" value="<?php echo $sab_p1; ?>" /></td>
        <td><input class="form-control" type="text" name="sab_a1" value="<?php echo $sab_a1; ?>" /></td>
      </tr>
      <tr>
        <td><input class="form-control" type="text" name="sab_h2" value="<?php echo $sab_h2; ?>" /></td>
        <td><input class="form-control" type="text" name="sab_p2" value="<?php echo $sab_p2; ?>" /></td>
        <td><input class="form-control" type="text" name="sab_a2" value="<?php echo $sab_a2; ?>" /></td>
      </tr>
      <tr>
        <td><input class="form-control" type="text" name="sab_h3" value="<?php echo $sab_h3; ?>" /></td>
        <td><input class="form-control" type="text" name="sab_p3" value="<?php echo $sab_p3; ?>" /></td>
        <td><input class="form-control" type="text" name="sab_a3" value="<?php echo $sab_a3; ?>" /></td>
      </tr>
            <tr>
        <td><input class="form-control" type="text" name="sab_h4" value="<?php echo $sab_h4; ?>" /></td>
        <td><input class="form-control" type="text" name="sab_p4" value="<?php echo $sab_p4; ?>" /></td>
        <td><input class="form-control" type="text" name="sab_a4" value="<?php echo $sab_a4; ?>" /></td>
      </tr>
            <tr>
        <td><input class="form-control" type="text" name="sab_h5" value="<?php echo $sab_h5; ?>" /></td>
        <td><input class="form-control" type="text" name="sab_p5" value="<?php echo $sab_p5; ?>" /></td>
        <td><input class="form-control" type="text" name="sab_a5" value="<?php echo $sab_a5; ?>" /></td>
      </tr>
            <tr>
        <td><input class="form-control" type="text" name="sab_h6" value="<?php echo $sab_h6; ?>" /></td>
        <td><input class="form-control" type="text" name="sab_p6" value="<?php echo $sab_p6; ?>" /></td>
        <td><input class="form-control" type="text" name="sab_a6" value="<?php echo $sab_a6; ?>" /></td>
      </tr>
      <tr>
        <td><input class="form-control" type="text" name="sab_h7" value="<?php echo $sab_h7; ?>" /></td>
        <td><input class="form-control" type="text" name="sab_p7" value="<?php echo $sab_p7; ?>" /></td>
        <td><input class="form-control" type="text" name="sab_a7" value="<?php echo $sab_a7; ?>" /></td>
      </tr>
      <tr>
        <td><input class="form-control" type="text" name="sab_h8" value="<?php echo $sab_h8; ?>" /></td>
        <td><input class="form-control" type="text" name="sab_p8" value="<?php echo $sab_p8; ?>" /></td>
        <td><input class="form-control" type="text" name="sab_a8" value="<?php echo $sab_a8; ?>" /></td>
      </tr>
            <tr>
        <td><input class="form-control" type="text" name="sab_h9" value="<?php echo $sab_h9; ?>" /></td>
        <td><input class="form-control" type="text" name="sab_p9" value="<?php echo $sab_p9; ?>" /></td>
        <td><input class="form-control" type="text" name="sab_a9" value="<?php echo $sab_a9; ?>" /></td>
      </tr>
      <tr>
        <td><input class="form-control" type="text" name="sab_h10" value="<?php echo $sab_h10; ?>" /></td>
        <td><input class="form-control" type="text" name="sab_p10" value="<?php echo $sab_p10; ?>" /></td>
        <td><input class="form-control" type="text" name="sab_a10" value="<?php echo $sab_a10; ?>" /></td>
      </tr>
    </tbody>
  </table>
</div>

    <button class="btn btn-success" type = "submit"><i class="fa fa-floppy-o"></i> Salvar</button>
</div>
</div>
</div>
</div>
</div>

  <div id="dom" class="tab-pane fade">
<br/>
<div class="col-md-6">
                     <!--   Basic Table  -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
              Domingo
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">

         
  <div class="form-group">

 <table>
    <thead>
      <tr>
        <th>Horário</th>
        <th>Programa</th>
        <th>Apresentador</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td><input class="form-control" type="text" name="dom_h1" value="<?php echo $dom_h1; ?>" /></td>
        <td><input class="form-control" type="text" name="dom_p1" value="<?php echo $dom_p1; ?>" /></td>
        <td><input class="form-control" type="text" name="dom_a1" value="<?php echo $dom_a1; ?>" /></td>
      </tr>
      <tr>
        <td><input class="form-control" type="text" name="dom_h2" value="<?php echo $dom_h2; ?>" /></td>
        <td><input class="form-control" type="text" name="dom_p2" value="<?php echo $dom_p2; ?>" /></td>
        <td><input class="form-control" type="text" name="dom_a2" value="<?php echo $dom_a2; ?>" /></td>
      </tr>
      <tr>
        <td><input class="form-control" type="text" name="dom_h3" value="<?php echo $dom_h3; ?>" /></td>
        <td><input class="form-control" type="text" name="dom_p3" value="<?php echo $dom_p3; ?>" /></td>
        <td><input class="form-control" type="text" name="dom_a3" value="<?php echo $dom_a3; ?>" /></td>
      </tr>
            <tr>
        <td><input class="form-control" type="text" name="dom_h4" value="<?php echo $dom_h4; ?>" /></td>
        <td><input class="form-control" type="text" name="dom_p4" value="<?php echo $dom_p4; ?>" /></td>
        <td><input class="form-control" type="text" name="dom_a4" value="<?php echo $dom_a4; ?>" /></td>
      </tr>
            <tr>
        <td><input class="form-control" type="text" name="dom_h5" value="<?php echo $dom_h5; ?>" /></td>
        <td><input class="form-control" type="text" name="dom_p5" value="<?php echo $dom_p5; ?>" /></td>
        <td><input class="form-control" type="text" name="dom_a5" value="<?php echo $dom_a5; ?>" /></td>
      </tr>
            <tr>
        <td><input class="form-control" type="text" name="dom_h6" value="<?php echo $dom_h6; ?>" /></td>
        <td><input class="form-control" type="text" name="dom_p6" value="<?php echo $dom_p6; ?>" /></td>
        <td><input class="form-control" type="text" name="dom_a6" value="<?php echo $dom_a6; ?>" /></td>
      </tr>
      <tr>
        <td><input class="form-control" type="text" name="dom_h7" value="<?php echo $dom_h7; ?>" /></td>
        <td><input class="form-control" type="text" name="dom_p7" value="<?php echo $dom_p7; ?>" /></td>
        <td><input class="form-control" type="text" name="dom_a7" value="<?php echo $dom_a7; ?>" /></td>
      </tr>
      <tr>
        <td><input class="form-control" type="text" name="dom_h8" value="<?php echo $dom_h8; ?>" /></td>
        <td><input class="form-control" type="text" name="dom_p8" value="<?php echo $dom_p8; ?>" /></td>
        <td><input class="form-control" type="text" name="dom_a8" value="<?php echo $dom_a8; ?>" /></td>
      </tr>
            <tr>
        <td><input class="form-control" type="text" name="dom_h9" value="<?php echo $dom_h9; ?>" /></td>
        <td><input class="form-control" type="text" name="dom_p9" value="<?php echo $dom_p9; ?>" /></td>
        <td><input class="form-control" type="text" name="dom_a9" value="<?php echo $dom_a9; ?>" /></td>
      </tr>
      <tr>
        <td><input class="form-control" type="text" name="dom_h10" value="<?php echo $dom_h10; ?>" /></td>
        <td><input class="form-control" type="text" name="dom_p10" value="<?php echo $dom_p10; ?>" /></td>
        <td><input class="form-control" type="text" name="dom_a10" value="<?php echo $dom_a10; ?>" /></td>
      </tr>
    </tbody>
  </table>
</div>

    <button class="btn btn-success" type = "submit"><i class="fa fa-floppy-o"></i> Salvar</button>
</div>
</div>
</div>
</div>
</div>


  <?php greenCheckmark();?>
    </form>
<?php } ?>

</div>