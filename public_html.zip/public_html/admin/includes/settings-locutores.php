<div class="col-md-12">
<br/>
<h2>Locutores</h2>
<h5>Olá <?php echo $perfil_nome; ?>, sou seu tutor virtual. Aqui você poderá cadastrar locutores.</h5>
<br/>
</div>

<form role="form" action = "index.php?p=settings-locutores" method = "post">

<?php

require_once("login.php");

if ($_POST["status"] == 1) {

     if (isset($_SESSION["token"])
        && isset($_SESSION["token_time"])
        && isset($_POST["token"])
        && $_SESSION["token"] == $_POST["token"]) {

        $timestamp_old = time() - (60*60);

        if ($_SESSION["token_time"] >= $timestamp_old) {

	        foreach ($_POST as $var => $key) {
                $$var = htmlspecialchars(trim(stripslashes($key)), ENT_QUOTES, "UTF-8");
            }

$config_locutores = '<?php
$locutor_select = "'. $locutor_select.'";
$pedido_select = "'. $pedido_select.'";
$msg_offline = "'. $msg_offline.'";
$locutor1_nome = "'. $locutor1_nome .'";
$programa1_nome = "'. $programa1_nome .'";
$locutor2_nome = "'. $locutor2_nome .'";
$programa2_nome = "'. $programa2_nome .'";
$locutor3_nome = "'. $locutor3_nome .'";
$programa3_nome = "'. $programa3_nome .'";
$locutor4_nome = "'. $locutor4_nome .'";
$programa4_nome = "'. $programa4_nome .'";
$locutor5_nome = "'. $locutor5_nome .'";
$programa5_nome = "'. $programa5_nome .'";
$locutor6_nome = "'. $locutor6_nome .'";
$programa6_nome = "'. $programa6_nome .'";
$locutor7_nome = "'. $locutor7_nome .'";
$programa7_nome = "'. $programa7_nome .'";
$locutor8_nome = "'. $locutor8_nome .'";
$programa8_nome = "'. $programa8_nome .'";
$locutor9_nome = "'. $locutor9_nome .'";
$programa9_nome = "'. $programa9_nome .'";
$locutor10_nome = "'. $locutor10_nome .'";
$programa10_nome = "'. $programa10_nome .'";
?>';

            if ($fp = fopen("bd/locutores.php", "w")) {
                fwrite($fp, $config_locutores, strlen($config_locutores));

                $_SESSION["saved"]=true;
                $host  = $_SERVER['HTTP_HOST'];
				$uri   = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
				header("Location: http://$host$uri/index.php?p=settings-locutores");
				die();

            } else {
                echo "<p class=\"errorMsg\">$lang_settings_unwritable</p>";
            }
        }
    }
}

if (empty($_SESSION["token"]) || $_SESSION["token_time"] <= $timestamp_old){
		 $_SESSION["token"]      = md5(uniqid(rand(), TRUE));
		 $_SESSION["token_time"] = time();
}

if (!isset($_POST["status"])) {
?>

<div class="form-group">
	   <label>No Ar</label>
	   <select class="form-peq" name="locutor_select">

	   <?php
	   $locutor_select_options = array(
	        array($locutor1_nome,'locutor1.php'),
	        array($locutor2_nome,'locutor2.php'),
	        array($locutor3_nome,'locutor3.php'),
	        array($locutor4_nome,'locutor4.php'),
	        array($locutor5_nome,'locutor5.php'),
	        array($locutor6_nome,'locutor6.php'),
	        array($locutor7_nome,'locutor7.php'),
	        array($locutor8_nome,'locutor8.php'),
	        array($locutor9_nome,'locutor9.php'),
	   		array($locutor10_nome,'locutor10.php')
	   		);

	   foreach ($locutor_select_options as $locutor_select_option) {

		?><option value = "<?php echo $locutor_select_option[1]; ?>"<?php echo $locutor_select == $locutor_select_option[1] ? 'selected="selected"' : '';?>><?php echo ucfirst($locutor_select_option[0]); ?></option><?php
			  } ?>
	   </select>
	</div>

  <div class="form-group">
     <label>Pedido de Músicas</label>
     <select class="form-peq" name="pedido_select">

     <?php
     $pedido_select_options = array(
          array(Ativar,'pedido-on.php'),
        array(Desativar,'pedido-off.php')
        );

     foreach ($pedido_select_options as $pedido_select_option) {

    ?><option value = "<?php echo $pedido_select_option[1]; ?>"<?php echo $pedido_select == $pedido_select_option[1] ? 'selected="selected"' : '';?>><?php echo ucfirst($pedido_select_option[0]); ?></option><?php
        } ?>
     </select>
  </div>
  <div class="form-group">
      <label>Mensagem Pedido Offline</label>
      <input class="form-control" type="text" name="msg_offline" value="<?php echo $msg_offline; ?>" />
  </div>



	<button class="btn btn-success" type = "submit"><i class="fa fa-floppy-o"></i> Salvar</button> 
	<br/>
	<br/>
	<br/>



<div class="col-md-6">
                     <!--   Basic Table  -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
							Locutor Padrão - AutoDJ
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">

        
                        
<div class="form-group">
<label>Foto</label>
      <br/>
      <img id="output" src="assets/img/locutores/padrao.png?img=<?php echo urlencode($cache_today); ?>" width="209" height="auto" />
<br/>Tamanho recomendando: 215x215 pixels.
<script>
  var loadFile = function(event) {
    var output = document.getElementById('output');
    output.src = URL.createObjectURL(event.target.files[0]);
  };
</script>
<br/>
<a class="btn btn-default" href="index.php?p=locutor1" ><i class="fa fa-pencil-square-o"></i> Editar Foto</a> 	    
<br/>
<br/>
</div>
	<div class="form-group">
	    <label>Nome</label>
	    <input class="form-control" type="text" name="locutor1_nome" value="<?php echo $locutor1_nome; ?>" />
	</div>

		<div class="form-group">
	    <label>Programa</label>
	    <input class="form-control" type="text" name="programa1_nome" value="<?php echo $programa1_nome; ?>" />
	</div>

    <input type="hidden" name="status" value="1" />
    <input type="hidden" name="token" value="<?php echo $_SESSION["token"]; ?>" />
    <button class="btn btn-success" type = "submit"><i class="fa fa-floppy-o"></i> Salvar</button>
</div>
</div>
</div>
</div>

<div class="col-md-6">
                     <!--   Basic Table  -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
							Locutor 2
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">

        
                        
<div class="form-group">
<label>Foto</label>
      <br/>
      <img id="output" src="assets/img/locutores/locutor2.png?img=<?php echo urlencode($cache_today); ?>" width="209" height="auto" />
<br/>Tamanho recomendando: 215x215 pixels.
<script>
  var loadFile = function(event) {
    var output = document.getElementById('output');
    output.src = URL.createObjectURL(event.target.files[0]);
  };
</script>
<br/>
<a class="btn btn-default" href="index.php?p=locutor2" ><i class="fa fa-pencil-square-o"></i> Editar Foto</a> 	    
<br/>
<br/>
</div>
	<div class="form-group">
	    <label>Nome</label>
	    <input class="form-control" type="text" name="locutor2_nome" value="<?php echo $locutor2_nome; ?>" />
	</div>

		<div class="form-group">
	    <label>Programa</label>
	    <input class="form-control" type="text" name="programa2_nome" value="<?php echo $programa2_nome; ?>" />
	</div>

    <button class="btn btn-success" type = "submit"><i class="fa fa-floppy-o"></i> Salvar</button>
</div>
</div>
</div>
</div>

<div class="col-md-6">
                     <!--   Basic Table  -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
							Locutor 3
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">

<div class="form-group">
<label>Foto</label>
      <br/>
      <img id="output" src="assets/img/locutores/locutor3.png?img=<?php echo urlencode($cache_today); ?>" width="209" height="auto" />
<br/>Tamanho recomendando: 215x215 pixels.
<script>
  var loadFile = function(event) {
    var output = document.getElementById('output');
    output.src = URL.createObjectURL(event.target.files[0]);
  };
</script>
<br/>
<a class="btn btn-default" href="index.php?p=locutor3" ><i class="fa fa-pencil-square-o"></i> Editar Foto</a> 	    
<br/>
<br/>
</div>
	<div class="form-group">
	    <label>Nome</label>
	    <input class="form-control" type="text" name="locutor3_nome" value="<?php echo $locutor3_nome; ?>" />
	</div>

		<div class="form-group">
	    <label>Programa</label>
	    <input class="form-control" type="text" name="programa3_nome" value="<?php echo $programa3_nome; ?>" />
	</div>

    <button class="btn btn-success" type = "submit"><i class="fa fa-floppy-o"></i> Salvar</button>
</div>
</div>
</div>
</div>

<div class="col-md-6">
                     <!--   Basic Table  -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
							Locutor 4
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">

        
                        
<div class="form-group">
<label>Foto</label>
      <br/>
      <img id="output" src="assets/img/locutores/locutor4.png?img=<?php echo urlencode($cache_today); ?>" width="209" height="auto" />
<br/>Tamanho recomendando: 215x215 pixels.
<script>
  var loadFile = function(event) {
    var output = document.getElementById('output');
    output.src = URL.createObjectURL(event.target.files[0]);
  };
</script>
<br/>
<a class="btn btn-default" href="index.php?p=locutor4" ><i class="fa fa-pencil-square-o"></i> Editar Foto</a> 	    
<br/>
<br/>
</div>
	<div class="form-group">
	    <label>Nome</label>
	    <input class="form-control" type="text" name="locutor4_nome" value="<?php echo $locutor4_nome; ?>" />
	</div>

		<div class="form-group">
	    <label>Programa</label>
	    <input class="form-control" type="text" name="programa4_nome" value="<?php echo $programa4_nome; ?>" />
	</div>

    <button class="btn btn-success" type = "submit"><i class="fa fa-floppy-o"></i> Salvar</button>
</div>
</div>
</div>
</div>

<div class="col-md-6">
                     <!--   Basic Table  -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
							Locutor 5
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">

        
                        
<div class="form-group">
<label>Foto</label>
      <br/>
      <img id="output" src="assets/img/locutores/locutor5.png?img=<?php echo urlencode($cache_today); ?>" width="209" height="auto" />
<br/>Tamanho recomendando: 215x215 pixels.
<script>
  var loadFile = function(event) {
    var output = document.getElementById('output');
    output.src = URL.createObjectURL(event.target.files[0]);
  };
</script>
<br/>
<a class="btn btn-default" href="index.php?p=locutor5" ><i class="fa fa-pencil-square-o"></i> Editar Foto</a> 	    
<br/>
<br/>
</div>
	<div class="form-group">
	    <label>Nome</label>
	    <input class="form-control" type="text" name="locutor5_nome" value="<?php echo $locutor5_nome; ?>" />
	</div>

		<div class="form-group">
	    <label>Programa</label>
	    <input class="form-control" type="text" name="programa5_nome" value="<?php echo $programa5_nome; ?>" />
	</div>

    <button class="btn btn-success" type = "submit"><i class="fa fa-floppy-o"></i> Salvar</button>
</div>
</div>
</div>
</div>

<div class="col-md-6">
                     <!--   Basic Table  -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
							Locutor 6
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">

        
                        
<div class="form-group">
<label>Foto</label>
      <br/>
      <img id="output" src="assets/img/locutores/locutor6.png?img=<?php echo urlencode($cache_today); ?>" width="209" height="auto" />
<br/>Tamanho recomendando: 215x215 pixels.
<script>
  var loadFile = function(event) {
    var output = document.getElementById('output');
    output.src = URL.createObjectURL(event.target.files[0]);
  };
</script>
<br/>
<a class="btn btn-default" href="index.php?p=locutor6" ><i class="fa fa-pencil-square-o"></i> Editar Foto</a> 	    
<br/>
<br/>
</div>
	<div class="form-group">
	    <label>Nome</label>
	    <input class="form-control" type="text" name="locutor6_nome" value="<?php echo $locutor6_nome; ?>" />
	</div>

		<div class="form-group">
	    <label>Programa</label>
	    <input class="form-control" type="text" name="programa6_nome" value="<?php echo $programa6_nome; ?>" />
	</div>

    <button class="btn btn-success" type = "submit"><i class="fa fa-floppy-o"></i> Salvar</button>
</div>
</div>
</div>
</div>


<div class="col-md-6">
                     <!--   Basic Table  -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
							Locutor 7
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">

        
                        
<div class="form-group">
<label>Foto</label>
      <br/>
      <img id="output" src="assets/img/locutores/locutor7.png?img=<?php echo urlencode($cache_today); ?>" width="209" height="auto" />
<br/>Tamanho recomendando: 215x215 pixels.
<script>
  var loadFile = function(event) {
    var output = document.getElementById('output');
    output.src = URL.createObjectURL(event.target.files[0]);
  };
</script>
<br/>
<a class="btn btn-default" href="index.php?p=locutor7" ><i class="fa fa-pencil-square-o"></i> Editar Foto</a> 	    
<br/>
<br/>
</div>
	<div class="form-group">
	    <label>Nome</label>
	    <input class="form-control" type="text" name="locutor7_nome" value="<?php echo $locutor7_nome; ?>" />
	</div>

		<div class="form-group">
	    <label>Programa</label>
	    <input class="form-control" type="text" name="programa7_nome" value="<?php echo $programa7_nome; ?>" />
	</div>

    <button class="btn btn-success" type = "submit"><i class="fa fa-floppy-o"></i> Salvar</button>
</div>
</div>
</div>
</div>

<div class="col-md-6">
                     <!--   Basic Table  -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
							Locutor 8
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">

        
                        
<div class="form-group">
<label>Foto</label>
      <br/>
      <img id="output" src="assets/img/locutores/locutor8.png?img=<?php echo urlencode($cache_today); ?>" width="209" height="auto" />
<br/>Tamanho recomendando: 215x215 pixels.
<script>
  var loadFile = function(event) {
    var output = document.getElementById('output');
    output.src = URL.createObjectURL(event.target.files[0]);
  };
</script>
<br/>
<a class="btn btn-default" href="index.php?p=locutor8" ><i class="fa fa-pencil-square-o"></i> Editar Foto</a> 	    
<br/>
<br/>
</div>
	<div class="form-group">
	    <label>Nome</label>
	    <input class="form-control" type="text" name="locutor8_nome" value="<?php echo $locutor8_nome; ?>" />
	</div>

		<div class="form-group">
	    <label>Programa</label>
	    <input class="form-control" type="text" name="programa8_nome" value="<?php echo $programa8_nome; ?>" />
	</div>

    <button class="btn btn-success" type = "submit"><i class="fa fa-floppy-o"></i> Salvar</button>
</div>
</div>
</div>
</div>


<div class="col-md-6">
                     <!--   Basic Table  -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
							Locutor 9
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">

        
                        
<div class="form-group">
<label>Foto</label>
      <br/>
      <img id="output" src="assets/img/locutores/locutor9.png?img=<?php echo urlencode($cache_today); ?>" width="209" height="auto" />
<br/>Tamanho recomendando: 215x215 pixels.
<script>
  var loadFile = function(event) {
    var output = document.getElementById('output');
    output.src = URL.createObjectURL(event.target.files[0]);
  };
</script>
<br/>
<a class="btn btn-default" href="index.php?p=locutor9" ><i class="fa fa-pencil-square-o"></i> Editar Foto</a> 	    
<br/>
<br/>
</div>
	<div class="form-group">
	    <label>Nome</label>
	    <input class="form-control" type="text" name="locutor9_nome" value="<?php echo $locutor9_nome; ?>" />
	</div>

		<div class="form-group">
	    <label>Programa</label>
	    <input class="form-control" type="text" name="programa9_nome" value="<?php echo $programa9_nome; ?>" />
	</div>

    <button class="btn btn-success" type = "submit"><i class="fa fa-floppy-o"></i> Salvar</button>
</div>
</div>
</div>
</div>

<div class="col-md-6">
                     <!--   Basic Table  -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
							Locutor 10
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">

        
                        
<div class="form-group">
<label>Foto</label>
      <br/>
      <img id="output" src="assets/img/locutores/locutor10.png?img=<?php echo urlencode($cache_today); ?>" width="209" height="auto" />
<br/>Tamanho recomendando: 215x215 pixels.
<script>
  var loadFile = function(event) {
    var output = document.getElementById('output');
    output.src = URL.createObjectURL(event.target.files[0]);
  };
</script>
<br/>
<a class="btn btn-default" href="index.php?p=locutor10" ><i class="fa fa-pencil-square-o"></i> Editar Foto</a> 	    
<br/>
<br/>
</div>
	<div class="form-group">
	    <label>Nome</label>
	    <input class="form-control" type="text" name="locutor10_nome" value="<?php echo $locutor10_nome; ?>" />
	</div>

		<div class="form-group">
	    <label>Programa</label>
	    <input class="form-control" type="text" name="programa10_nome" value="<?php echo $programa10_nome; ?>" />
	</div>

    <button class="btn btn-success" type = "submit"><i class="fa fa-floppy-o"></i> Salvar</button>
</div>
</div>
</div>
</div>

  <?php greenCheckmark();?>
    </form>
<?php } ?>
