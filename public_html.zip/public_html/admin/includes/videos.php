<?php
require_once("login.php");

$on = 'videos';

if (!empty($_POST)) {
   $filename = "data/videos/videosfile.txt";

   if (isset($_POST['message'])) {
	$date    = $_POST['date'];
	$subject = $_POST['subject'];
	$message = $_POST['message'];

	$fp   = fopen($filename,"r") or die($lang_blog_error_reading); 
	$data = @fread($fp, filesize($filename));
    fclose($fp);
            
    $line = explode("\n", $data);
    $no_of_posts = count($line)-1;
           
	
	for ($i=0; $i<$no_of_posts; $i++) {
        $blog = explode("|", $line[$i]);
		$posts[$i] = $blog[0];
	}
    
    if(count($posts) > 0) {
	    $no_of_posts = max($posts)+1;
	} else {
	     $no_of_posts = 1;
	}
	
	$subject = htmlspecialchars(trim(stripslashes($subject)), ENT_QUOTES, "UTF-8");
	$message = strip_tags(stripslashes($message), "<p><center><u><strong><audio><iframe><del><link><object><fieldset><dl><dt><dt><colgroup><col><font><label><embed><a><pre><b><i><style><table><tbody><td><textarea><tfoot><th><thead><title><tr><tt><ul><li><ol><img><h1><h2><h3><h4><h5><hr><address><span><div><blockquote><br><br /><button>");

	$message  = trim($message);
	$postdate = date("D, d M Y H:i:s O");
	$message  = str_replace("\n", "", $message);
	$message  = str_replace("\r", "", $message);
	$message  = str_replace("|", "&brvbar;", $message);

	$blog = $no_of_posts ."|0|". $postdate ."|". $subject ."|". $message."\n";

	$data = fopen($filename, "a");
	fwrite($data, $blog);
	fclose($data);
	
	$host  = $_SERVER['HTTP_HOST'];
	$uri   = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
	header("Location: http://$host$uri/index.php?p=manage-videos");
	die();
  }
}

?>
<div class="col-md-12">

<div id="panel-body">
<br/>
	<a class="btn btn-primary" href="index.php?p=manage-videos"><i class="fa fa-chevron-circle-left"></i> Voltar</a>
	<button onclick="document.editor.submit();" class="btn btn-success"><i class="fa fa-floppy-o"></i> <?php echo $lang_blocks_save; ?></button>
</div>
<br />


                    <!-- Advanced Tables -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
                             Novo Vídeo
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">
<div id="" class="max">
	<form class="editor" name="editor" action="" method="post" name="post">
		<label><?php echo $lang_blog_label_title; ?></label>
		<input class="form-control" type="text" name="subject" maxlength="70" value="" />
		<br/>
		<label>ID Vídeo Youtube</label>
		<input class="form-control" type="text" name="message" wrap="virtual" placeholder="Exemplo: UeD4kMNS5pQ"/>
	</form>
</div>
                            </div>
                            
                        </div>
                    </div>
                    <!--End Advanced Tables -->
                </div>