<?php 
//Geral
$lang_page_title = "Painel Administrativo";
$lang_go_back = "< Voltar";
$lang_yes = "Sim";
$lang_cancel = "Cancelar";
$lang_embed = "Código Embutido";
$lang_embed_desc = "Este é o seu código de incorporação, colá-lo em um bloco, página ou em um <b> .php </ b> página para exibir este conteúdo.";
$lang_help = "- Breno Solutions";
$lang_save = "Salvar";

// Login

$lang_login_incorrect = "Sua senha é incorreta!";
$lang_login_button = "Entrar";

// Navegação

$lang_nav_blocks = "Blocos";
$lang_nav_galleries = "Mídias";
$lang_nav_blog = "Postagens";
$lang_nav_backup = "Backup";
$lang_nav_settings = "Configurações";
$lang_nav_logout = "Sair";
$lang_nav_form = "Formulários";
$lang_nav_stats = "Estatística";
$lang_nav_pages = "Páginas";


// Configurações

$lang_setting_lang = "Escolha o idioma";
$lang_setting_general = "Geral";
$lang_setting_gallery = "Galeria";
$lang_setting_blog = "Blog";
$lang_setting_blog_date = "Clique <a href='http://php.net/manual/en/function.date.php'>here</a> para mais informações sobre os formatos de data php.";
$lang_setting_folder = "Caminho do Painel";
$lang_setting_folder_hint = "Se o painel não está na raiz de domínio, adicionar as sub-pastas à sua frente. Ex: acesso/admin";
$lang_setting_password = "Senha";
$lang_setting_gal_style = "Estilo da Galeria";
$lang_setting_gal_slider = "Slider";
$lang_setting_gal_thumbs = "Miniaturas";
$lang_setting_date = "Post Formato data";
$lang_setting_blog_url = "Blog URL";
$lang_setting_blog_url_hint = "Nota: Digite a URL completa em que você colocou o código do blog de incorporação.";
$lang_setting_blog_posts = "Posts Por Página";
$lang_setting_blog_comments = "Comentários";
$lang_setting_blog_enabled = "Ativar";
$lang_setting_blog_disabled = "Desativar";
$lang_setting_spam_questions = "Perguntas Anti-Spam";
$lang_setting_spam_questions_hint = "Para melhor proteção, escrever suas próprias perguntas originais.";
$lang_setting_spam_question = "Pergunta";
$lang_setting_spam_answer = "Resposta";
$lang_settings_unwritable = "Arquivo de configuração gravável.";
$lang_email_contact = "E-mail de Contato";
$lang_setting_rewrite_hint = "Leia as instruções em <b>/htaccess_sample</b>.";
$lang_setting_tim_height = "Altura";
$lang_setting_tim_width = "Largura";
$lang_setting_gallery_thumbnails = "Galeria de Miniaturas";

// Páginas

$lang_pages_session_expire = "Sua sessão expirou. <a href=\"index.php?p=logout\">Entrar Novamente.</a>";
$lang_pages_sure_del_block = "Tem certeza de que deseja excluir esta página?";
$lang_pages_cant_find_page = "Não é possível encontrar nesta página. Verifique o caminho eo nome da página estão corretos.";
$lang_pages_newpage = "Nova Página";
$lang_pages_emptyfold = "Esta pasta está vazia. ";
$lang_pages_file_exists = "Uma página com este nome já existe.";
$lang_pages_not_created = "Não foi possível criar.";
$lang_pages_pagename = "Nome da Página";
$lang_pages_url = "URL";
$lang_pages_title = "Título da página";
$lang_pages_description = "Descrição da Página";
$lang_pages_content = "Conteúdo da Página";

// Blocos

$lang_blocks_newblock = "Novo Bloco";
$lang_blocks_newfold = "Nova Pasta";
$lang_blocks_fold_name = "Nome da Pasta";
$lang_blocks_create_button = "Criar";
$lang_blocks_delfold = "Excluir Pasta";
$lang_blocks_delblock = "Excluir";
$lang_blocks_sure_del_block = "Tem certeza de que deseja apagar este bloco?";
$lang_blocks_blockname = "Nome do Bloco";
$lang_blocks_create = "Criar";
$lang_blocks_fold_exists = "Esta pasta já existe.";
$lang_blocks_home = "Início";
$lang_blocks_save = "Salvar";
$lang_blocks_move = "Mover para:";
$lang_blocks_emptyfold = "Esta pasta está vazia. ";
$lang_blocks_session_expire = "Sua sessão expirou. <a href=\"index.php?p=logout\">Entrar Novamente.</a>";
$lang_blocks_sure_delete_fold = "Tem certeza de que deseja excluir esta pasta?";
$lang_blocks_cant_find_fold = "Não é possível localizar esta pasta. Verifique se o caminho eo nome da pasta estão corretas.";
$lang_blocks_cant_find_block = "Não é possível localizar este bloco. Verifique o caminho eo nome do bloco estão corretas.";
$lang_blocks_not_created = " Não foi possível criar.";
$lang_blocks_file_exists = "Um bloco com este nome já existe.";
$lang_blocks_rename_try_again = "Tente novamente";
$lang_blocks_rename_btn = "Renomear";

// Galerias e Mídias

$lang_gal_newgal = "Nova Galeria";
$lang_gal_upload = "Carregar Novo";
$lang_gal_preview = "Visualizar";
$lang_gal_del_gallery = "Excluir Galeria";
$lang_gal_newname = "Nome da Galeria";
$lang_gal_create_gal = "Criar";
$lang_gal_sure_delete = "Tem certeza de que deseja excluir toda a galeria?";
$lang_gal_upload = "Carregar Foto";
$lang_gal_select = "Por favor, selecione o arquivo abaixo e clique em enviar.";
$lang_gal_max = "Tamanho máximo: 5mb";
$lang_gal_upload_button = "Carregar";
$lang_gal_session_expired = "Sua sessão expirou. <a href=\"index.php?p=logout\">Entrar Novamente.</a>";
$lang_gal_cant_find = "Não é possível encontrar esta galeria. Verifique o caminho eo nome da galeria estão corretas.";
$lang_gal_sure_delete_file = "Tem certeza de que deseja excluir: ";
$lang_gal_cant_find_file = "Não é possível encontrar este arquivo. Verifique o caminho eo nome da galeria estão corretas.";
$lang_gal_empty = "Esta galeria está vazio.";
$lang_gal_error = "Erro, uma galeria com o mesmo nome existir já!";
$lang_gal_no_gal = "Não há galerias criado ainda.";
$lang_gal_delete = "Excluir";
$lang_gal_noexist = "Esta galeria não existe.";
$lang_gal_file_exists = " Já existe.";
$lang_gal_file_invalid = "Arquivo inválido: tamanho Max: 5mb";
$lang_gal_view_images = "Ver imagens";
$lang_gal_upload_another = "Carregar outra imagem";
$lang_gal_invalid_gal = "Galeria inválida: Por favor selecione uma galeria";
$lang_gal_caption_gallery = "Insira legenda aqui";
$lang_gal_preview_thumb_preview = "Miniaturas pré-visualizar" ;
$lang_gal_preview_slider_preview = "Slider pré-visualizar";
$lang_gal_close_preview = "Fechar";
$lang_gal_gallery_preview = "Galeria pré-visualização";

// Estatística

$lang_stats_today = "Visitantes";
$lang_stats_refers = "Top Referências";
$lang_stats_pages = "Top páginas";
$lang_stats_refresh = "Atualizar";
$lang_stats_pageviews = "Visualizações de Páginas";
$lang_stats_embed = "Cole este código em todas as páginas que você deseja acompanhar (Direito antes do fechamento &lt;/body&gt; tag).";
$lang_stats_per_visit = "Páginas / visita";
$lang_stats_online = "Online";
$lang_stats_thisweek = "Esta Semana";
$lang_stats_todays_stats = "Estatísticas de hoje";
$lang_stats_nodata = "Sem Dados";

// Backup

$lang_backup_now = "Backup Agora";
$lang_backup_del_confirm = "Tem certeza de que deseja excluir este backup?";
$lang_backup_err_destination = "Erro ao criar o destino.";
$lang_backup_session_expired = "Sessão Expirada";
$lang_backup_err_zip_extension = "<b>Aviso:</b> PHP Extensão Zip PHP não é habilitado no servidor. Backup não funcionarão. Contacte o seu host para habilitá-lo.";

// Formulário de Contato

$lang_form_preview_only = "Isto é uma <b>pre-visualização</b> somente, ele não irá enviar email. Defina o destino de e-mail nas configurações.";
$lang_form_label_name = "Nome";
$lang_form_label_email = "E-mail";
$lang_form_label_comment = "Mensagem";
$lang_form_send = "Enviar";
$lang_form_subject = "Contato - $page_title ";
$lang_form_message_sent = "Sua mensagem foi enviada. Obrigado.";
$lang_form_not_sent = "A sua mensagem não foi enviada.";
$lang_form_all_fields = "Por favor, preencha todos os campos.";
$lang_form_valid_email = "Por favor insira um endereço de e-mail válido.";
$lang_form_info = "Informações";
$lang_form_capcha_option = "Esconder Captcha";

// Blog

$lang_blog_error_reading = "Erro de leitura do Arquivo";
$lang_blog_error_check = "Por favor, verifique o seu nome ou e-mail ou comentário.";
$lang_blog_error_name = "Digite um nome";
$lang_blog_error_email = "Digite um endereço de e-mail";
$lang_blog_error_comment = "Insira um comentário";
$lang_blog_error_captcha = "Tente novamente.";
$lang_blog_add_comment = "Adicione um comentário";
$lang_blog_label_name = "nome";
$lang_blog_label_email = "E-mail (não Pública)";
$lang_blog_label_comment = "Comentário";
$lang_blog_num_comment = "Comentários";
$lang_blog_no_comment = "Sem comentários";
$lang_blog_older = "Posts Antigos >";
$lang_blog_newer = "< Posts Recentes";
$lang_blog_submit = "Confirmar";
$lang_blog_more = "Leia Mais &rarr;";
$lang_blog_main_embed = "Blog Página Principal:";
$lang_blog_notify = "Há um novo comentário no seu blog.";
$lang_blog_subject = "Novo Comentário";
$lang_blog_title = "Título";
$lang_blog_name = "Nome";
$lang_blog_comment = "Comentário";
$lang_blog_off_comments = "Os comentários estão agora fechados.";
$lang_blog_comment_off = "Desativar comentários";
$lang_blog_comment_on = "Ativar comentários";
$lang_blog_capcha = "Captcha comentários";

// Manage Blog

$lang_blog_new_post = "Nova postagem";
$lang_blog_preview = "Pre-visualizar";
$lang_blog_posts = "Posts de Blog";
$lang_blog_session_expire = "Sua sessão expirou . <a href=\"index.php?p=logout\">Tente novamente.</a>";
$lang_blog_sure_delete = "Tem certeza de que deseja excluir ?";
$lang_blog_cant_find = "Não é possível localizar este post.";
$lang_blog_label_title = "Título";
$lang_blog_label_body = "Corpo";
$lang_blog_button_update = "Atualizar";
$lang_blog_comment_delete = "Excluir";
$lang_blog_no_post = "Nenhum post encontrado";
$lang_blog_post_delete = "Excluir";
$lang_blog_post_edit = "Editar";
$lang_blog_button_publish = "Publicar";
$lang_blog_posted = "Postado com sucesso";
$lang_blog_post_empty = "A mensagem é vazia";
$lang_blog_post_updated = "Blog foi atualizado com sucesso";

?>