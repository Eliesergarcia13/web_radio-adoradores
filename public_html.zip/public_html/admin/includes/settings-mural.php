<div class="col-md-12">
<br/>
<h2>Mural</h2>
<h5>Olá <?php echo $perfil_nome; ?>, sou seu tutor virtual. Aqui você poderá configurar o sistema Mural de Recados.</h5>
<br/>
</div>

<div class="col-md-6">
                     <!--   Basic Table  -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
							Configurações do Mural
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">

<form action="" method="post">
   <?php
 $espaco = " ";
 if (isset($_POST['limpar'])){
 $cria = fopen("bd/recados.php","w");
 fwrite($cria, $espaco);
}
?>
<div class="form-group">
<label>Limpar Mural</label>
<button class="btn btn-excluir" name="limpar"><i class="fa fa-eraser"></i> Limpar</button>

</div>
</form>

<form role="form" action = "index.php?p=settings-mural" method = "post">

<?php
require_once("login.php");

if ($_POST["status"] == 1) {

     if (isset($_SESSION["token"])
        && isset($_SESSION["token_time"])
        && isset($_POST["token"])
        && $_SESSION["token"] == $_POST["token"]) {

        $timestamp_old = time() - (60*60);

        if ($_SESSION["token_time"] >= $timestamp_old) {

	        foreach ($_POST as $var => $key) {
                $$var = htmlspecialchars(trim(stripslashes($key)), ENT_QUOTES, "UTF-8");
            }

$config_mural = '<?php
$mural = "'. $mural .'";
$mural_pag = "'. $mural_pag .'";
?>';

            if ($fp = fopen("bd/mural.php", "w")) {
                fwrite($fp, $config_mural, strlen($config_mural));

                $_SESSION["saved"]=true;
                $host  = $_SERVER['HTTP_HOST'];
				$uri   = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
				header("Location: http://$host$uri/index.php?p=settings-mural");
				die();

            } else {
                echo "<p class=\"errorMsg\">$lang_settings_unwritable</p>";
            }
        }
    }
}

if (empty($_SESSION["token"]) || $_SESSION["token_time"] <= $timestamp_old){
		 $_SESSION["token"]      = md5(uniqid(rand(), TRUE));
		 $_SESSION["token_time"] = time();
}

if (!isset($_POST["status"])) {
?>


  <div class="form-group">
     <label>Ativar / Desativar</label>
     <select class="form-control" name="mural">

     <?php
     $mural_options = array(
        array(Ativar Mural,'1'),
        array(Desativar Mural,'0')
        );

     foreach ($mural_options as $mural_option) {

    ?><option value = "<?php echo $mural_option[1]; ?>"<?php echo $mural == $mural_option[1] ? 'selected="selected"' : '';?>><?php echo ucfirst($mural_option[0]); ?></option><?php
        } ?>
     </select>
  </div>



    <div class="form-group">
      <label>Recados por Página</label>
      <input class="form-control"  type="number" name="mural_pag" value="<?php echo empty($mural_pag) ? 5 : $mural_pag; ?>" />
    </div>



<div class="form-group">
    <input type="hidden" name="status" value="1" />
    <input type="hidden" name="token" value="<?php echo $_SESSION["token"]; ?>" />
    <button class="btn btn-success" type = "submit"><i class="fa fa-floppy-o"></i> Salvar</button> 
  <?php greenCheckmark();?>
  </div>
    </form>


<?php } ?>
</div>
</div>
</div>
</div>

