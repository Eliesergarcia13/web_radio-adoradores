<div class="col-md-12">
<br/>
<h2>Câmera do Estúdio</h2>
<h5>Olá <?php echo $perfil_nome; ?>, sou seu tutor virtual. Aqui você poderá configurar Câmera do Estúdio.</h5>
<br/>
</div>

<div class="col-md-6">
                     <!--   Basic Table  -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
							Configurações
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">



<form role="form" action = "index.php?p=settings-tv" method = "post">

<?php
require_once("login.php");

if ($_POST["status"] == 1) {

     if (isset($_SESSION["token"])
        && isset($_SESSION["token_time"])
        && isset($_POST["token"])
        && $_SESSION["token"] == $_POST["token"]) {

        $timestamp_old = time() - (60*60);

        if ($_SESSION["token_time"] >= $timestamp_old) {

	        foreach ($_POST as $var => $key) {
                $$var = htmlspecialchars(trim(stripslashes($key)), ENT_QUOTES, "UTF-8");
            }

$config_tv = '<?php
$tv = "'. $tv .'";
$code_tv = "'. $code_tv .'";
$nome_tv = "'. $nome_tv .'";

?>';

            if ($fp = fopen("bd/tv.php", "w")) {
                fwrite($fp, $config_tv, strlen($config_tv));

                $_SESSION["saved"]=true;
                $host  = $_SERVER['HTTP_HOST'];
				$uri   = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
				header("Location: http://$host$uri/index.php?p=settings-tv");
				die();

            } else {
                echo "<p class=\"errorMsg\">$lang_settings_unwritable</p>";
            }
        }
    }
}

if (empty($_SESSION["token"]) || $_SESSION["token_time"] <= $timestamp_old){
		 $_SESSION["token"]      = md5(uniqid(rand(), TRUE));
		 $_SESSION["token_time"] = time();
}

if (!isset($_POST["status"])) {
?>


  <div class="form-group">
     <label>Ativar / Desativar</label>
     <select class="form-control" name="tv">

     <?php
     $tv_options = array(
        array(Ativar Câmera,'1'),
        array(Desativar Câmera,'0')
        );

     foreach ($tv_options as $tv_option) {

    ?><option value = "<?php echo $tv_option[1]; ?>"<?php echo $tv == $tv_option[1] ? 'selected="selected"' : '';?>><?php echo ucfirst($tv_option[0]); ?></option><?php
        } ?>
     </select>
  </div>
  <div class="form-group">
     <label>Box Nome</label>
     <input class="form-control" type="text" name="nome_tv" value="<?php echo $nome_tv; ?>"/>

     </br>
   </div>

  <div class="panel panel-default">
                        <div class="panel-heading">
                            Player TV - Código
                        </div>
                        
                        <div class="panel-body">
                        <div class="table-responsive">           
                        
<?php include_once($_SERVER["DOCUMENT_ROOT"]."/admin/data/pages/camera-estudio.html"); ?>   
<br/>
<a class="btn btn-default" href="index.php?p=manage-pages" ><i class="fa fa-pencil-square-o"></i> <b>Alterar Widget</b></a>       

    </div>

</div>
</div>


<div class="form-group">
    <input type="hidden" name="status" value="1" />
    <input type="hidden" name="token" value="<?php echo $_SESSION["token"]; ?>" />
    <button class="btn btn-success" type = "submit"><i class="fa fa-floppy-o"></i> Salvar</button> 
  <?php greenCheckmark();?>
  </div>
    </form>


<?php } ?>
</div>
</div>
</div>
</div>

