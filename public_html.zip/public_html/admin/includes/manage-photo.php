<?php 
	
$on = 'images'; 
require_once("login.php");

?>

<div class="col-md-12">
<br/>
<h2>Imagens</h2>   
<h5>Olá <?php echo $perfil_nome; ?>, sou seu tutor virtual. Aqui você poderá carregar, editar e excluir fotos.</h5>
<div id="panel-body">
<br/>
	<a class="btn btn-primary" href = "index.php?p=choose-img&g=<?php if (!empty($_GET["g"])) { echo htmlentities($_GET["g"]); }?>"><i class="fa fa-cloud-upload"></i> <?php echo $lang_gal_upload; ?>s</a>
	    
</div>
<br />

                    <!-- Advanced Tables -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
                             Lista de fotos
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">

<?php 

if (!empty($_GET["g"])) {
	$gallery = strip_tags(trim(stripslashes(htmlspecialchars($_GET["g"], ENT_QUOTES, 'UTF-8'))));
	$gallery = str_replace("/","", $gallery);
	$gallery = str_replace("\\","", $gallery);	
    $gallery = str_replace("..", "",  $_GET["g"]);
    
    $opFile = ROOTPATH . "/data/img/gallery/". $gallery ."/gallery.txt";
    
    if (file_exists($opFile)) {    
    	$fp   = fopen($opFile,"r");
        $data = @fread($fp, filesize($opFile));
        fclose($fp);

        $line = explode("\n", $data);
        $nb   = count($line)-1;
               
		$image = sortImages($line);
          
        ?><ul id = "sortable" > <?php
              
        for ($i = 0; $i < $nb+1; $i++) {
            
	      if ($image[$i][1] == $gallery) { 
	  	        	       	 		        		        				     		        		        
		  ?>		        
	           <ul class = "thumb" id = "one_<?php echo $image[$i][0]; ?>"><?php
		          
                echo '<a href="index.php?p=captions&f='. $image[$i][0] .'&g='. $image[$i][1] .'">';
                echo '<img src="data/img/gallery/'. $gallery .'/'. $image[$i][2] .'" alt="'. $image[$i][3] .'"  class="thumb-pic"/>';
                echo '</a>';
                echo '<a href="index.php?p=captions&f='. $image[$i][0] .'&g='. $image[$i][1] .'">';
                echo '<img src="img/pencil-icon.png" class="mag-glass" />';
                echo '</a>';
                echo "<a href=\"index.php?p=del-img&f=". $image[$i][0] ."&g=". $gallery ."\" class=\"del-img\">$lang_gal_delete</a>";
               
           ?> </ul> <?php 
                
	       }
         }
        
       ?> </ul> <div id = "result"></div> <?php
      } 
    
    if ($nb <= 0) {
        echo "<p class=\"empty\">". $lang_gal_empty ."</p><br><br>";        
    }
}
?>
 
<script type = "text/javascript">
$ (function() {
    $("#sortable").sortable({ 
	  update: function() {
        var order = $(this).sortable("serialize")+ '&gallery=<?php echo $gallery;  ?>';
	        $.post("includes/helpers/gal-sort.php", order, function(theResponse){
	        $("#result").html(theResponse);
			});
        } 
    });
});
</script>

<div class = "clear"></div>

</div>                            </div>
                            
                        </div>
                    </div>
                    <!--End Advanced Tables -->
                </div>