<div class="col-md-12">
<META http-equiv="refresh" content="5"> 
<br/>
<h2>Pedido de Música</h2>   
<br/>

                    <!-- Advanced Tables -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
                             Pedidos
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">

<table class="table table-striped">
<tr>
    <th>Nome</th>
    <th>E-mail</th>
    <th>Pedido</th>
    <th>Data/hora</th>
</tr>
<?php include "bd/pedidos.php"; ?>



                                </table>
<form action="" method="post">
 <?php
 if (isset($_POST['limpar'])){
 unset($linhas);
 $cria = fopen("bd/pedidos.php","w+");
 fclose($cria);
 echo "<p>Lista de Pedidos Limpos!</p> <META http-equiv='refresh' content='0'> ";
}
?>
<br/><br/>
<button class="btn btn-excluir" name="limpar"><i class="fa fa-eraser"></i> Limpar</button>
</form>

</div>
</div>                            </div>
                        </div>