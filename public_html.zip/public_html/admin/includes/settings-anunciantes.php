<div class="col-md-12">
<br/>
<h2>Anunciantes</h2>
<h5>Olá <?php echo $perfil_nome; ?>, sou seu tutor virtual. Aqui você poderá cadastrar anunciantes.</h5>
<br/>
</div>

<form role="form" action = "index.php?p=settings-anunciantes" method = "post">

<?php
require_once("login.php");

if ($_POST["status"] == 1) {

     if (isset($_SESSION["token"])
        && isset($_SESSION["token_time"])
        && isset($_POST["token"])
        && $_SESSION["token"] == $_POST["token"]) {

        $timestamp_old = time() - (60*60);

        if ($_SESSION["token_time"] >= $timestamp_old) {

	        foreach ($_POST as $var => $key) {
                $$var = htmlspecialchars(trim(stripslashes($key)), ENT_QUOTES, "UTF-8");
            }

$config_anunciantes = '<?php

$anun_nome1 = "'. $anun_nome1 .'";
$anun_link1 = "'. $anun_link1 .'";
$anun_nome2 = "'. $anun_nome2 .'";
$anun_link2 = "'. $anun_link2 .'";
$anun_nome3 = "'. $anun_nome3 .'";
$anun_link3 = "'. $anun_link3 .'";
$anun_nome4 = "'. $anun_nome4 .'";
$anun_link4 = "'. $anun_link4 .'";
$anun_nome5 = "'. $anun_nome5 .'";
$anun_link5 = "'. $anun_link5 .'";
$anun_nome6 = "'. $anun_nome6 .'";
$anun_link6 = "'. $anun_link6 .'";
$anun_nome7 = "'. $anun_nome7 .'";
$anun_link7 = "'. $anun_link7 .'";
$anun_nome8 = "'. $anun_nome8 .'";
$anun_link8 = "'. $anun_link8 .'";

?>';

            if ($fp = fopen("bd/anunciantes.php", "w")) {
                fwrite($fp, $config_anunciantes, strlen($config_anunciantes));

                $_SESSION["saved"]=true;
                $host  = $_SERVER['HTTP_HOST'];
				$uri   = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
				header("Location: http://$host$uri/index.php?p=settings-anunciantes");
				die();

            } else {
                echo "<p class=\"errorMsg\">$lang_settings_unwritable</p>";
            }
        }
    }
}

if (empty($_SESSION["token"]) || $_SESSION["token_time"] <= $timestamp_old){
		 $_SESSION["token"]      = md5(uniqid(rand(), TRUE));
		 $_SESSION["token_time"] = time();
}

if (!isset($_POST["status"])) {
?>

<div class="col-md-6">
                     <!--   Basic Table  -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
							Anunciante 1
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">

        
                        
<div class="form-group">
<label>Banner</label>
      <br/>
      <img id="output" src="assets/img/anunciantes/anuncio1.png?img=<?php echo urlencode($cache_today); ?>" width="209" height="auto" />
<br/>Tamanho recomendando: 270x270 pixels.
<script>
  var loadFile = function(event) {
    var output = document.getElementById('output');
    output.src = URL.createObjectURL(event.target.files[0]);
  };
</script>
<br/>
<a class="btn btn-default" href="index.php?p=anuncio1" ><i class="fa fa-pencil-square-o"></i> Alterar Banner</a> 	    
<br/>
<br/>
</div>
	<div class="form-group">
	    <label>Nome</label>
	    <input class="form-control" type="text" name="anun_nome1" value="<?php echo $anun_nome1; ?>" />
	</div>

		<div class="form-group">
	    <label>Site</label>
	    <input class="form-control" type="text" name="anun_link1" value="<?php echo $anun_link1; ?>" />
	</div>

    <input type="hidden" name="status" value="1" />
    <input type="hidden" name="token" value="<?php echo $_SESSION["token"]; ?>" />
    <button class="btn btn-success" type = "submit"><i class="fa fa-floppy-o"></i> Salvar</button>
</div>
</div>
</div>
</div>

<div class="col-md-6">
                     <!--   Basic Table  -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
              Anunciante 2
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">

        
                        
<div class="form-group">
<label>Banner</label>
      <br/>
      <img id="output" src="assets/img/anunciantes/anuncio2.png?img=<?php echo urlencode($cache_today); ?>" width="209" height="auto" />
<br/>Tamanho recomendando: 270x270 pixels.
<script>
  var loadFile = function(event) {
    var output = document.getElementById('output');
    output.src = URL.createObjectURL(event.target.files[0]);
  };
</script>
<br/>
<a class="btn btn-default" href="index.php?p=anuncio2" ><i class="fa fa-pencil-square-o"></i> Alterar Banner</a>      
<br/>
<br/>
</div>
  <div class="form-group">
      <label>Nome</label>
      <input class="form-control" type="text" name="anun_nome2" value="<?php echo $anun_nome2; ?>" />
  </div>

    <div class="form-group">
      <label>Site</label>
      <input class="form-control" type="text" name="anun_link2" value="<?php echo $anun_link2; ?>" />
  </div>

    <button class="btn btn-success" type = "submit"><i class="fa fa-floppy-o"></i> Salvar</button>
</div>
</div>
</div>
</div>

<div class="col-md-6">
                     <!--   Basic Table  -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
              Anunciante 3
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">

        
                        
<div class="form-group">
<label>Banner</label>
      <br/>
      <img id="output" src="assets/img/anunciantes/anuncio3.png?img=<?php echo urlencode($cache_today); ?>" width="209" height="auto" />
<br/>Tamanho recomendando: 270x270 pixels.
<script>
  var loadFile = function(event) {
    var output = document.getElementById('output');
    output.src = URL.createObjectURL(event.target.files[0]);
  };
</script>
<br/>
<a class="btn btn-default" href="index.php?p=anuncio3" ><i class="fa fa-pencil-square-o"></i> Alterar Banner</a>      
<br/>
<br/>
</div>
  <div class="form-group">
      <label>Nome</label>
      <input class="form-control" type="text" name="anun_nome3" value="<?php echo $anun_nome3; ?>" />
  </div>

    <div class="form-group">
      <label>Site</label>
      <input class="form-control" type="text" name="anun_link3" value="<?php echo $anun_link3; ?>" />
  </div>

    <button class="btn btn-success" type = "submit"><i class="fa fa-floppy-o"></i> Salvar</button>
</div>
</div>
</div>
</div>

<div class="col-md-6">
                     <!--   Basic Table  -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
              Anunciante 4
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">

        
                        
<div class="form-group">
<label>Banner</label>
      <br/>
      <img id="output" src="assets/img/anunciantes/anuncio4.png?img=<?php echo urlencode($cache_today); ?>" width="209" height="auto" />
<br/>Tamanho recomendando: 270x270 pixels.
<script>
  var loadFile = function(event) {
    var output = document.getElementById('output');
    output.src = URL.createObjectURL(event.target.files[0]);
  };
</script>
<br/>
<a class="btn btn-default" href="index.php?p=anuncio4" ><i class="fa fa-pencil-square-o"></i> Alterar Banner</a>      
<br/>
<br/>
</div>
  <div class="form-group">
      <label>Nome</label>
      <input class="form-control" type="text" name="anun_nome4" value="<?php echo $anun_nome4; ?>" />
  </div>

    <div class="form-group">
      <label>Site</label>
      <input class="form-control" type="text" name="anun_link4" value="<?php echo $anun_link4; ?>" />
  </div>

    <button class="btn btn-success" type = "submit"><i class="fa fa-floppy-o"></i> Salvar</button>
</div>
</div>
</div>
</div>

<div class="col-md-6">
                     <!--   Basic Table  -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
              Anunciante 5
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">

        
                        
<div class="form-group">
<label>Banner</label>
      <br/>
      <img id="output" src="assets/img/anunciantes/anuncio5.png?img=<?php echo urlencode($cache_today); ?>" width="209" height="auto" />
<br/>Tamanho recomendando: 270x270 pixels.
<script>
  var loadFile = function(event) {
    var output = document.getElementById('output');
    output.src = URL.createObjectURL(event.target.files[0]);
  };
</script>
<br/>
<a class="btn btn-default" href="index.php?p=anuncio5" ><i class="fa fa-pencil-square-o"></i> Alterar Banner</a>      
<br/>
<br/>
</div>
  <div class="form-group">
      <label>Nome</label>
      <input class="form-control" type="text" name="anun_nome5" value="<?php echo $anun_nome5; ?>" />
  </div>

    <div class="form-group">
      <label>Site</label>
      <input class="form-control" type="text" name="anun_link5" value="<?php echo $anun_link5; ?>" />
  </div>

    <button class="btn btn-success" type = "submit"><i class="fa fa-floppy-o"></i> Salvar</button>
</div>
</div>
</div>
</div>

<div class="col-md-6">
                     <!--   Basic Table  -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
              Anunciante 6
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">

        
                        
<div class="form-group">
<label>Banner</label>
      <br/>
      <img id="output" src="assets/img/anunciantes/anuncio6.png?img=<?php echo urlencode($cache_today); ?>" width="209" height="auto" />
<br/>Tamanho recomendando: 270x270 pixels.
<script>
  var loadFile = function(event) {
    var output = document.getElementById('output');
    output.src = URL.createObjectURL(event.target.files[0]);
  };
</script>
<br/>
<a class="btn btn-default" href="index.php?p=anuncio6" ><i class="fa fa-pencil-square-o"></i> Alterar Banner</a>      
<br/>
<br/>
</div>
  <div class="form-group">
      <label>Nome</label>
      <input class="form-control" type="text" name="anun_nome6" value="<?php echo $anun_nome6; ?>" />
  </div>

    <div class="form-group">
      <label>Site</label>
      <input class="form-control" type="text" name="anun_link6" value="<?php echo $anun_link6; ?>" />
  </div>

    <button class="btn btn-success" type = "submit"><i class="fa fa-floppy-o"></i> Salvar</button>
</div>
</div>
</div>
</div>

<div class="col-md-6">
                     <!--   Basic Table  -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
              Anunciante 7
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">

        
                        
<div class="form-group">
<label>Banner</label>
      <br/>
      <img id="output" src="assets/img/anunciantes/anuncio7.png?img=<?php echo urlencode($cache_today); ?>" width="209" height="auto" />
<br/>Tamanho recomendando: 270x270 pixels.
<script>
  var loadFile = function(event) {
    var output = document.getElementById('output');
    output.src = URL.createObjectURL(event.target.files[0]);
  };
</script>
<br/>
<a class="btn btn-default" href="index.php?p=anuncio7" ><i class="fa fa-pencil-square-o"></i> Alterar Banner</a>      
<br/>
<br/>
</div>
  <div class="form-group">
      <label>Nome</label>
      <input class="form-control" type="text" name="anun_nome7" value="<?php echo $anun_nome7; ?>" />
  </div>

    <div class="form-group">
      <label>Site</label>
      <input class="form-control" type="text" name="anun_link7" value="<?php echo $anun_link7; ?>" />
  </div>

    <button class="btn btn-success" type = "submit"><i class="fa fa-floppy-o"></i> Salvar</button>
</div>
</div>
</div>
</div>

<div class="col-md-6">
                     <!--   Basic Table  -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
              Anunciante 8
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">

        
                        
<div class="form-group">
<label>Banner</label>
      <br/>
      <img id="output" src="assets/img/anunciantes/anuncio8.png?img=<?php echo urlencode($cache_today); ?>" width="209" height="auto" />
<br/>Tamanho recomendando: 270x270 pixels.
<script>
  var loadFile = function(event) {
    var output = document.getElementById('output');
    output.src = URL.createObjectURL(event.target.files[0]);
  };
</script>
<br/>
<a class="btn btn-default" href="index.php?p=anuncio8" ><i class="fa fa-pencil-square-o"></i> Alterar Banner</a>      
<br/>
<br/>
</div>
  <div class="form-group">
      <label>Nome</label>
      <input class="form-control" type="text" name="anun_nome8" value="<?php echo $anun_nome8; ?>" />
  </div>

    <div class="form-group">
      <label>Site</label>
      <input class="form-control" type="text" name="anun_link8" value="<?php echo $anun_link8; ?>" />
  </div>

    <button class="btn btn-success" type = "submit"><i class="fa fa-floppy-o"></i> Salvar</button>
</div>
</div>
</div>
</div>

  <?php greenCheckmark();?>
    </form>
<?php } ?>
