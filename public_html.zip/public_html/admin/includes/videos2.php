
<?php
error_reporting(0);
include_once("path.php");
include_once(ROOTPATH."../../config.php");
include_once("lang/$pulse_lang.php");
include_once("helpers/functions.php");
include_once("helpers/videos_lib.php");

// Get Conteudo
$get_videos = new show_Videos;
?>

<?php
echo "<div class='blog-wrap'> \n";
if ($get_videos->val_videos($_GET["d"]) == true) {	

} else{ 

// Show all posts
foreach ($get_videos->get_blog_videos(3, $lang_blog_more) as $videos) {
	echo "<div class='col-lg-4 col-md-4 col-sm-4'>";
	echo "<div class='latest-videos'>";
	echo "<div class='video-feed'>";
    
	echo "<div class='embed-container'><iframe src=\"https://www.youtube.com/embed/$videos[4]\" frameborder=\"0\" allowfullscreen></iframe></div><br/>\n";
	echo "<h5>".date($order, strtotime($videos[2]))."</h5>";
		     
	echo "</div></div></div>\n";
}

// Pagination

echo '<div class="news-feed-btn">';
$nums = $get_videos->amount_pages_videos(3);
if ($nums[1] < $nums[0]) { echo "<a href=\"videos-page-".($nums[1]+1)."\">Vídeos Antigos ></a>"; }
if ($nums[1] > 1) { echo  "<a href=\"videos-page-".($nums[1]-1)."\">< Vídeos Recentes</a>"; }
echo '</div>';
}
echo '</div>';
// Fim

?>
