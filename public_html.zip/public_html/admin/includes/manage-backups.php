<?php 
require_once("login.php");
if (!extension_loaded('zip')) { 
    echo $lang_backup_err_zip_extension; 
}

if (isset($_GET['b']) && file_exists("data/backups/".$_GET['b'].".zip")){
	$download  = "data/backups/".$_GET['b'].".zip";
    $file_name = basename($download);

    header("Content-Type: application/zip");
    header("Content-Disposition: attachment; filename=$file_name");
    header("Content-Length: " . filesize($download));
    readfile($download);    
    exit;
}

?>
<div class="col-md-12">
<br/>
<h2>Backups</h2>   
<h5>Olá <?php echo $perfil_nome; ?>, sou seu tutor virtual. Aqui você poderá gerar, excluir e baixa backups.   </h5>
<br/>

	<a class="btn btn-success" href = "index.php?p=backup"><i class="fa fa-cloud-download"></i> <?php echo $lang_backup_now; ?></a>
<br/>
<br/>
                    <!-- Advanced Tables -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
                             Lista de backups
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">

<div id = "">	            
<div class = "backup-list">

<?php 
	
$files = glob("data/backups/*");
rsort($files);
	
if ($files) {
	
    foreach ($files as $file) { 
        $short = (pathinfo($file));
        
        if (!is_dir($file)) {
	        ?>
	        <div class="tab zips">
	        <a href = "index.php?p=manage-backups&b=<?php echo $short['filename']; ?>">
	        <?php $file = preg_replace("/\\.[^.\\s]{3,4}$/", "", $file); echo basename($file);?>.zip</a>
	        <?php $t = basename($file);?>
	        <a class="del-backup" href="index.php?p=del-backup&f=<?php echo htmlentities($t);?>">x</a> 
	        </div>
	        <?php 
	    }
	}
} 
$_SESSION["backups"] = $backups;		
?>
</div>
</div>                            </div>
                            
                        </div>
                    </div>
                    <!--End Advanced Tables -->
                </div>