<?php if (isset($_POST['license'])) {
    $license = $_POST['license'];
        
   }

$o = $_SERVER['SERVER_NAME']; ?>