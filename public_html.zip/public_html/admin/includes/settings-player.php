<div class="col-md-12">
<br/>
<h2>Player</h2>
<h5>Olá <?php echo $perfil_nome; ?>, sou seu tutor virtual. Aqui você poderá configurar seu player.</h5>
<br/>
</div>

<div class="col-md-6">
                     <!--   Basic Table  -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
							Configurações do Player
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">

<form role="form" action = "index.php?p=settings-player" method = "post">

<?php
require_once("login.php");

if ($_POST["status"] == 1) {

     if (isset($_SESSION["token"])
        && isset($_SESSION["token_time"])
        && isset($_POST["token"])
        && $_SESSION["token"] == $_POST["token"]) {

        $timestamp_old = time() - (60*60);

        if ($_SESSION["token_time"] >= $timestamp_old) {

	        foreach ($_POST as $var => $key) {
                $$var = htmlspecialchars(trim(stripslashes($key)), ENT_QUOTES, "UTF-8");
            }

$config_player = '<?php
$back_player = "'. $back_player .'";
$nome_stream = "'. $nome_stream .'";
$pos_player = "'. $pos_player .'";
$player_on = "'. $player_on .'";



?>';

            if ($fp = fopen("bd/player.php", "w")) {
                fwrite($fp, $config_player, strlen($config_player));

                $_SESSION["saved"]=true;
                $host  = $_SERVER['HTTP_HOST'];
				$uri   = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
				header("Location: http://$host$uri/index.php?p=settings-player");
				die();

            } else {
                echo "<p class=\"errorMsg\">$lang_settings_unwritable</p>";
            }
        }
    }
}

if (empty($_SESSION["token"]) || $_SESSION["token_time"] <= $timestamp_old){
		 $_SESSION["token"]      = md5(uniqid(rand(), TRUE));
		 $_SESSION["token_time"] = time();
}

if (!isset($_POST["status"])) {
?>
	<div class="form-group">
	    <label>Nome da Rádio</label>
	    <input class="form-control" type="text" name="nome_stream" value="<?php echo $nome_stream; ?>" />
	</div>

	<div class="form-group">
	    <label class="">Fundo</label>
	    <input class="" type="color" name="back_player" value="<?php echo $back_player; ?>" />
   </div>
	<div class="form-group">
	   <label>Posição</label>
	   <select class="form-control" name="pos_player">

	   <?php
	   $pos_player_options = array(
	      array(Topo,''),
	   		array(Rodapé,'fixed')
	   		);

	   foreach ($pos_player_options as $pos_player_option) {

		?><option value = "<?php echo $pos_player_option[1]; ?>"<?php echo $pos_player == $pos_player_option[1] ? 'selected="selected"' : '';?>><?php echo ucfirst($pos_player_option[0]); ?></option><?php
			  } ?>
	   </select>
	</div>

  <div class="form-group">
     <label>Ativar / Desativar</label>
     <select class="form-control" name="player_on">

     <?php
     $player_on_options = array(
        array(Ativar Player,'1'),
        array(Desativar Player,'0')
        );

     foreach ($player_on_options as $player_on_option) {

    ?><option value = "<?php echo $player_on_option[1]; ?>"<?php echo $player_on == $player_on_option[1] ? 'selected="selected"' : '';?>><?php echo ucfirst($player_on_option[0]); ?></option><?php
        } ?>
     </select>
  </div>
	


<div class="form-group">
    <input type="hidden" name="status" value="1" />
    <input type="hidden" name="token" value="<?php echo $_SESSION["token"]; ?>" />
    <button class="btn btn-success" type = "submit"><i class="fa fa-floppy-o"></i> Salvar</button> 
  <?php greenCheckmark();?>
  </div>
    </form>

  

<?php } ?>
</div>
</div>
</div>
</div>

