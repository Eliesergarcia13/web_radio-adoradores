<form action = "index.php?p=settings" method = "post">
<div class="panel-body">
<h2>Configurações</h2>
<h5>Olá <?php echo $perfil_nome; ?>, sou seu tutor virtual. Aqui você poderá editar todas as configurações do site.</h5>
<br/>

	<button class="btn btn-success" type = "submit"><i class="fa fa-floppy-o"></i> Salvar</button> 
  <?php greenCheckmark();?>
</div>

<div id = "content">

<?php
require_once("login.php");

if ($_POST["status"] == 1) {		

     if (isset($_SESSION["token"]) 
        && isset($_SESSION["token_time"]) 
        && isset($_POST["token"]) 
        && $_SESSION["token"] == $_POST["token"]) {
        
        $timestamp_old = time() - (60*60);

        if ($_SESSION["token_time"] >= $timestamp_old) {
	   
	        foreach ($_POST as $var => $key) {
                $$var = htmlspecialchars(trim(stripslashes($key)), ENT_QUOTES, "UTF-8");
            }

$config = '<?php
$pulse_dir = "admin";
$page_title = "'. $page_title .'";
$page_desc = "'. $page_desc .'";
$page_words = "'. $page_words .'";
$height = "270";
$width = "270";
$blog_url = "blog.php";
$menu_home = "'. $menu_home .'";
$menu_sobre = "'. $menu_sobre .'";
$menu_noticias = "'. $menu_noticias .'";
$menu_mural = "'. $menu_mural .'";
$menu_programacao = "'. $menu_programacao .'";
$menu_eventos = "'. $menu_eventos .'";
$menu_fotos = "'. $menu_fotos .'";
$menu_videos = "'. $menu_videos .'";
$menu_equipe = "'. $menu_equipe .'";
$menu_contato = "'. $menu_contato .'";
$youtube_url = "'. $youtube_url .'";
$analytics_id = "'. $analytics_id .'";
$per_page = "'. $posts_per .'";
$blog_comments = '. $comments .';
$blog_capcha = false;
$date_format = "'. $date_format .'";
$email_contact = "'. $email .'";
$nub_whatsapp = "'. $nub_whatsapp .'";
$facebook_url = "'. $facebook_url .'";
$twitter_url = "'. $twitter_url .'";
$google_url = "'. $google_url .'";
$linkedin_url = "'. $linkedin_url .'";
$pinterest_url = "'. $pinterest_url .'";
$instagram_url = "'. $instagram_url .'";
$flickr_url = "'. $flickr_url .'";
$pulse_lang = "PT_BR";
$custom_fieldname1 = "'. $custom_fieldname1 .'";
$custom_fieldname2 = "'. $custom_fieldname2 .'";
$formcap = "'. $formcap .'";
$corsite = "'. $corsite .'";

$apk_url = "'. $apk_url .'";
$ios_url = "'. $ios_url .'";
$apk_select = "'. $apk_select .'";
$ios_select = "'. $ios_select .'";


$bapk_select = "'. $bapk_select .'";
$bios_select = "'. $bios_select .'";
$bwin_select = "'. $bwin_select .'";
$bblack_select = "'. $bblack_select .'";

$bapk_url = "'. $bapk_url .'";
$bios_url = "'. $bios_url .'";
$bwin_url = "'. $bwin_url .'";
$bblack_url = "'. $bblack_url .'";


?>';

            if ($fp = fopen("../config.php", "w")) {
                fwrite($fp, $config, strlen($config));
                
                $_SESSION["saved"]=true;
                $host  = $_SERVER['HTTP_HOST'];
				$uri   = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
				header("Location: http://$host$uri/index.php?p=settings");
				die();
				
            } else {
                echo "<p class=\"errorMsg\">$lang_settings_unwritable</p>"; 
            }
        }       
    }
}

if (empty($_SESSION["token"]) || $_SESSION["token_time"] <= $timestamp_old){
		 $_SESSION["token"]      = md5(uniqid(rand(), TRUE));	
		 $_SESSION["token_time"] = time();
}

if (!isset($_POST["status"])) {
?>
    
    
 <style>

.accordion {
  padding: 0;
  margin: 2em 0;
  width: 100%;
  overflow: hidden;
  font-size: 1em;
  position: relative;
}

.accordion__title {
  padding: 0 1em;
  background: #ccc;
  border-top: 2px solid #eee;
  color: #222;
  float: left;
  line-height: 3;
  height: 3em;
  cursor: pointer;
  margin-right: .25em;
}

.no-js .accordion__title {
  float: none;
  height:auto;
  cursor:auto;
  margin:0;
  padding:0 2em;
}

.accordion__content {
  float: right;
  width: 100%;
  margin: 3em 0 0 -100%;
  padding: 0;
  background: fff;
}

.no-js .accordion__content {
  float:left;
  margin:0;
}

.accordion__title:hover,
.accordion__title.active {
  background: silver;
  color: white;
}

.no-js .accordion__title:hover {
  background-color:#ccc;
  color:#222;
}

.accordion__title.active {
  border-top-color:lime;
}

@media (max-width: 48em) {
  
  .accordion {
    border: 1px solid grey;
  }
  
  .accordion__title,
  .accordion__content { 
    float: none;
    margin: 0;
  }
  
  .accordion__title:first-child {
    border:none;
  }
  
 .accordion__title.active {
  border-top-color:#eee;
  }
  
  .accordion__title.active, .accordion__title:hover {
    background:#777;
  }
  
  .accordion__title:before {
  content:"+";
  text-align:center;
  width:2em;
  display:inline-block;
  }
 .accordion__title.active:before {
  content:"-";
  }
  
 .overflow-scrolling {
  overflow-y: scroll;
  height:11em;
  padding:1em 1em 0 1em;
  /* Warning: momemtum scrolling seems buggy on iOS 7  */
  -webkit-overflow-scrolling: touch;
  }

  .accordion__content {
    position:relative;
    overflow:hidden;
    padding:0;
  }
  
   .no-js .accordion__content {
    padding:1em;
    overflow:auto;
    display:block;
  }
  
  .accordion__content:after {
    position:absolute;
    top:100%;
    left:0;
    width:100%;
    height:50px;
    border-radius:10px 0 0 10px / 50% 0 0 50%;
    box-shadow:-5px 0 10px rgba(0, 0, 0, 0.5);
    content:'';
}
   
}
</style>   
    
   <div class="col-md-6">
    <dl class="accordion">

      <dt class="accordion__title">Geral</dt>
  <dd class="accordion__content">

   <br>
   <h2><?php echo $lang_setting_general; ?></h2>
<br/>
   <div class="form-group">
	    <label>Título do Site</label>
	    <input class="form-control "type="text" name="page_title" value="<?php echo $page_title; ?>" />
    </div>
	<div class="form-group">
	    <label>Descrição do Site</label>
	    <input class="form-control "type="text" name="page_desc" value="<?php echo $page_desc; ?>" />
    </div>
	    <div class="form-group">
	    <label>Keywords</label>
	    <input class="form-control "type="text" name="page_words" value="<?php echo $page_words; ?>" />
    </div>

    <div class="form-group">
     <label>Analytics ID</label>
     <input class="form-control" type="text" name="analytics_id" value="<?php echo $analytics_id; ?>"/>
   </div>


                        


<div class="panel panel-default">
                        <div class="panel-heading">
                            Alterar logo
                        </div>
                        
                        <div class="panel-body">
                        <div class="table-responsive">           
                        

      <br/>
      <img id="output" src="assets/img/logo.png?img=<?php echo urlencode($cache_today); ?>" width="209" height="auto" />
<br/>Tamanho recomendando: 186x69 pixels.
<script>
  var loadFile = function(event) {
    var output = document.getElementById('output');
    output.src = URL.createObjectURL(event.target.files[0]);
  };
</script>
<br/>
<a class="btn btn-default" href="index.php?p=settings-logo" ><i class="fa fa-pencil-square-o"></i> Alterar Logo</a> 	    

    </div>

</div>
</div>

<div class="panel panel-default">
                        <div class="panel-heading">
                            Alterar favicon
                        </div>
                        
                        <div class="panel-body">
                        <div class="table-responsive">           
                        

      <br/>
      <img id="output" src="assets/img/favicon.jpg" width="32" height="auto" />
<br/>Tamanho recomendando: 32x32 pixels.
<script>
  var loadFile = function(event) {
    var output = document.getElementById('output');
    output.src = URL.createObjectURL(event.target.files[0]);
  };
</script>
<br/>
<a class="btn btn-default" href="index.php?p=settings-favicon" ><i class="fa fa-pencil-square-o"></i> Alterar favicon</a>       

    </div>

</div>
</div>

<div class="panel panel-default">
                        <div class="panel-heading">
                            Alterar Background
                        </div>
                        <div class="panel-body">
                        <div class="table-responsive">           
                        
<a class="btn btn-default" href="index.php?p=manage-photo&g=Bg" ><i class="fa fa-pencil-square-o"></i> Alterar BG</a>      

    </div>

</div>
</div>

<div class="panel panel-default">
                        <div class="panel-heading">
                            Previsão do Tempo
                        </div>
                        
                        <div class="panel-body">
                        <div class="table-responsive">           
                        
<?php include_once($_SERVER["DOCUMENT_ROOT"]."/admin/data/pages/previsao-do-tempo.html"); ?>   
<br/>
<a class="btn btn-info" href="http://www.cptec.inpe.br/previsaonoseusite/pt" target="_bank">Obter Widget</a></p>
<a class="btn btn-default" href="index.php?p=manage-pages" ><i class="fa fa-pencil-square-o"></i> <b>Alterar Widget</b></a>       

    </div>

</div>
</div>


   <div class="form-group">
	   <label>Cor do Site</label>
	   <select class="form-control" name="corsite">

	   <?php
	   $corsite_options = array(
	      array(Padrão,'padrao'),
	   		array(Blue,'blue'),
	   		array(Orange,'orange'),
	   		array(Red,'red'),
	   		array(Green,'green'),
	   		array(Purple,'purple')
	   		);

	   foreach ($corsite_options as $corsite_option) {

		?><option value = "<?php echo $corsite_option[1]; ?>"<?php echo $corsite == $corsite_option[1] ? 'selected="selected"' : '';?>><?php echo ucfirst($corsite_option[0]); ?></option><?php

			  } ?>

	   </select>
   </div>

  <div class="form-group">
     <label>WhatsApp</label>
     <input class="form-control" type="text" name="nub_whatsapp" value="<?php echo $nub_whatsapp; ?>"/>

     </br>
   </div>

   <div class="form-group">
	   <label><?php echo $lang_email_contact; ?></label>
	   <input class="form-control" type="text" name="email" value="<?php echo $email_contact; ?>"/>
	   <p class="settings-hints">Use o e-mail local da hospedagem</p>
	   </br>
   </div>
</dd>

      <dt class="accordion__title">Social</dt>
  <dd class="accordion__content">

    <br>

    <h2>Social</h2>
<br/>
   <div class="form-group">
	   <label>Facebook</label>
	   <input class="form-control" type="text" name="facebook_url" value="<?php echo $facebook_url; ?>"/>
	   <p class="settings-hints">Coloque o url do Facebook</p>
   </div>
   <div class="form-group">
	   <label>Twitter</label>
	   <input class="form-control" type="text" name="twitter_url" value="<?php echo $twitter_url; ?>"/>
	   <p class="settings-hints">Coloque o url do Twitter</p>
   </div>

   <div class="form-group">
	   <label>Google+</label>
	   <input class="form-control" type="text" name="google_url" value="<?php echo $google_url; ?>"/>
	   <p class="settings-hints">Coloque o url do Google+</p>
   </div>
      <div class="form-group">
	   <label>linkedin</label>
	   <input class="form-control" type="text" name="linkedin_url" value="<?php echo $linkedin_url; ?>"/>
	   <p class="settings-hints">Coloque o url do Linkedin</p>
   </div>

     <div class="form-group">
	   <label>Pinterest</label>
	   <input class="form-control" type="text" name="pinterest_url" value="<?php echo $pinterest_url; ?>"/>
	   <p class="settings-hints">Coloque o url do Pinterest</p>
   </div>

   <div class="form-group">
     <label>Instagram</label>
     <input class="form-control" type="text" name="instagram_url" value="<?php echo $instagram_url; ?>"/>
     <p class="settings-hints">Coloque o url do Instagram</p>
   </div>

   <div class="form-group">
     <label>Flickr</label>
     <input class="form-control" type="text" name="flickr_url" value="<?php echo $flickr_url; ?>"/>
     <p class="settings-hints">Coloque o url do Flickr</p>
   </div>

   <div class="form-group">
	   <label>Youtube</label>
	   <input class="form-control" type="text" name="youtube_url" value="<?php echo $youtube_url; ?>"/>
	   <p class="settings-hints">Coloque o url do canal do Youtube</p>
   </div>

  </dd>

          <dt class="accordion__title">Post</dt>
  <dd class="accordion__content">
  <br/>
    <h2><?php echo $lang_setting_blog; ?></h2>
<br/>


    <div class="form-group">
	    <label><?php echo $lang_setting_blog_posts; ?></label>
	    <input class="form-control"  type="number" name="posts_per" value="<?php echo empty($per_page) ? 5 : $per_page; ?>" />
    </div>

    <div class="form-group">
    <?php if( ($date_format == '0') || ($date_format == '1')){ $date_format = 'd-m-Y';}?>
	    <label ><?php echo $lang_setting_date; ?></label>
		<input class="form-control" type="text" name="date_format" value="<?php echo $date_format; ?>"/>
		<p class="settings-hints"><?php echo $lang_setting_blog_date; ?></p>
    </div>

    <div class="form-group">
	    <label><?php echo $lang_setting_blog_comments; ?></label>
	    <select class="form-control" name="comments">
	    	<option value="true" <?php echo ($blog_comments) ? 'selected="selected"' : '';?>><?php echo $lang_setting_blog_enabled; ?></option>
	    	<option value="false" <?php echo ($blog_comments) ? '' : 'selected="selected"';?>><?php echo $lang_setting_blog_disabled; ?></option>
	    </select>
    </div>

</dd>
 <dt class="accordion__title">Menu</dt>
  <dd class="accordion__content">
<br/>

    <h2>Renomear menu</h2>
<br/>

   <div class="form-group">
	   <label>Home:</label>
	   <input class="form-control" type="text" name="menu_home" value="<?php echo $menu_home; ?>"/>
   </div>
   <div class="form-group">
	   <label>Sobre:</label>
	   <input class="form-control" type="text" name="menu_sobre" value="<?php echo $menu_sobre; ?>"/>
   </div>
   <div class="form-group">
	   <label>Notícias:</label>
	   <input class="form-control" type="text" name="menu_noticias" value="<?php echo $menu_noticias; ?>"/>
   </div>
   <div class="form-group">
     <label>Recados:</label>
     <input class="form-control" type="text" name="menu_mural" value="<?php echo $menu_mural; ?>"/>
   </div>

    <div class="form-group">
	   <label>Programação:</label>
	   <input class="form-control" type="text" name="menu_programacao" value="<?php echo $menu_programacao; ?>"/>
   </div>

    <div class="form-group">
	   <label>Eventos:</label>
	   <input class="form-control" type="text" name="menu_eventos" value="<?php echo $menu_eventos; ?>"/>
   </div>

  <div class="form-group">
     <label>Fotos:</label>
     <input class="form-control" type="text" name="menu_fotos" value="<?php echo $menu_fotos; ?>"/>
   </div>

    <div class="form-group">
     <label>Vídeos:</label>
     <input class="form-control" type="text" name="menu_videos" value="<?php echo $menu_videos; ?>"/>
   </div>

   <div class="form-group">
     <label>Equipe:</label>
     <input class="form-control" type="text" name="menu_equipe" value="<?php echo $menu_equipe; ?>"/>
   </div>

        <div class="form-group">
	   <label>Contato:</label>
	   <input class="form-control" type="text" name="menu_contato" value="<?php echo $menu_contato; ?>"/>
   </div>

  </dd>

  <dt class="accordion__title">Mobile</dt>
  <dd class="accordion__content">

    <br>

    <h2>Aplicativos</h2>
<br/>
  
  <div class="form-group">
     <label>Aplicativo Android</label>
     <input class="form-control" type="text" name="apk_url" value="<?php echo $apk_url; ?>"/>
     
         <select class="form-peq" name="apk_select">

     <?php
     $apk_select_options = array(
          array(Ativar,'apk.php'),
        array(Desativar,'appoff.php')
        );

     foreach ($apk_select_options as $apk_select_option) {

    ?><option value = "<?php echo $apk_select_option[1]; ?>"<?php echo $apk_select == $apk_select_option[1] ? 'selected="selected"' : '';?>><?php echo ucfirst($apk_select_option[0]); ?></option><?php
        } ?>
     </select>
   </div>

     <div class="form-group">
     <label>Aplicativo IOS</label>
     <input class="form-control" type="text" name="ios_url" value="<?php echo $ios_url; ?>"/>
     
         <select class="form-peq" name="ios_select">

     <?php
     $ios_select_options = array(
          array(Ativar,'ios.php'),
        array(Desativar,'appoff.php')
        );

     foreach ($ios_select_options as $ios_select_option) {

    ?><option value = "<?php echo $ios_select_option[1]; ?>"<?php echo $ios_select == $ios_select_option[1] ? 'selected="selected"' : '';?>><?php echo ucfirst($ios_select_option[0]); ?></option><?php
        } ?>
     </select>
   </div>

<br/><br/>
<h2>Botões Ouça no Celular</h2>
<br/>

    <div class="form-group">
     <label>Android:</label>
     <input class="form-control" type="text" name="bapk_url" value="<?php echo $bapk_url; ?>"/>
     <select class="form-peq" name="bapk_select">
     <?php
     $bapk_select_options = array(
        array(Ativar,'android.php'),
        array(Desativar,'off.php')
        );

     foreach ($bapk_select_options as $bapk_select_option) {

    ?><option value = "<?php echo $bapk_select_option[1]; ?>"<?php echo $bapk_select == $bapk_select_option[1] ? 'selected="selected"' : '';?>><?php echo ucfirst($bapk_select_option[0]); ?></option><?php
        } ?>
     </select>

   </div>
  <div class="form-group">
     <label>Iphone:</label>
     <input class="form-control" type="text" name="bios_url" value="<?php echo $bios_url; ?>"/>
      <select class="form-peq" name="bios_select">
     <?php
     $bios_select_options = array(
        array(Ativar,'iphone.php'),
        array(Desativar,'off.php')
        );

     foreach ($bios_select_options as $bios_select_option) {

    ?><option value = "<?php echo $bios_select_option[1]; ?>"<?php echo $bios_select == $bios_select_option[1] ? 'selected="selected"' : '';?>><?php echo ucfirst($bios_select_option[0]); ?></option><?php
        } ?>
     </select>

  </div>
    <div class="form-group">
     <label>Windows Phone:</label>
     <input class="form-control" type="text" name="bwin_url" value="<?php echo $bwin_url; ?>"/>
    
    <select class="form-peq" name="bwin_select">
     <?php
     $bwin_select_options = array(
        array(Ativar,'windows.php'),
        array(Desativar,'off.php')
        );

     foreach ($bwin_select_options as $bwin_select_option) {

    ?><option value = "<?php echo $bwin_select_option[1]; ?>"<?php echo $bwin_select == $bwin_select_option[1] ? 'selected="selected"' : '';?>><?php echo ucfirst($bwin_select_option[0]); ?></option><?php
        } ?>
     </select>

   </div>

  <div class="form-group">
     <label>BlackBerry:</label>
     <input class="form-control" type="text" name="bblack_url" value="<?php echo $bblack_url; ?>"/>
           <select class="form-peq" name="bblack_select">
     <?php
     $bblack_select_options = array(
        array(Ativar,'blackberry.php'),
        array(Desativar,'off.php')
        );

     foreach ($bblack_select_options as $bblack_select_option) {

    ?><option value = "<?php echo $bblack_select_option[1]; ?>"<?php echo $bblack_select == $bblack_select_option[1] ? 'selected="selected"' : '';?>><?php echo ucfirst($bblack_select_option[0]); ?></option><?php
        } ?>
     </select>

   </div>

  </dd>


    </dl>

    <input name="custom_fieldname1" type="hidden" value="<?php echo $custom_fieldname1; ?>" >
    <input name="custom_fieldname2" type="hidden" value="<?php echo $custom_fieldname2; ?>" >
    <input name="formcap" type="hidden" value = "<?php echo $formcap; ?> ">
    <input type="hidden" name="status" value="1" />
    <input type="hidden" name="token" value="<?php echo $_SESSION["token"]; ?>" />
    </form>

        <script>
if($(window).width() > 768){

// Hide all but first tab content on larger viewports
$('.accordion__content:not(:first)').hide();

// Activate first tab
$('.accordion__title:first-child').addClass('active');

} else {

// Hide all content items on narrow viewports
$('.accordion__content').hide();
};

// Wrap a div around content to create a scrolling container which we're going to use on narrow viewports
$( ".accordion__content" ).wrapInner( "<div class='overflow-scrolling'></div>" );

// The clicking action
$('.accordion__title').on('click', function() {
$('.accordion__content').hide();
$(this).next().show().prev().addClass('active').siblings().removeClass('active');
});
</script>
<?php } ?>
</div>
</div>