
<?php
error_reporting(0);
include_once("path.php");
include_once(ROOTPATH."../../config.php");
include_once("helpers/functions.php");
include_once("helpers/videos_lib.php");

// Get Conteudo
$get_videos = new show_Videos;
?>

<?php
if ($get_videos->val_videos($_GET["d"]) == true) {	

} else { 

// Mostrar Videos
foreach ($get_videos->get_blog_videos(4) as $videos) {
	echo "<div <div class='col-lg-6' >\n";
	echo "<div class='embed-container'><iframe src=\"https://www.youtube.com/embed/$videos[4]\" frameborder=\"0\" allowfullscreen></iframe></div>
	<div class='blog-date'>".date($order, strtotime($videos[2]))."</div>\n<br/>\n"; 
	echo "</div>\n";

	}

}
// Fim

?>
