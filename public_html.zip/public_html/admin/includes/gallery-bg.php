<?php 
error_reporting(0);
include_once("path.php"); 
include(ROOTPATH."../../config.php");

include_once("helpers/functions.php");
?>
<?php 
if (!empty($_GET["g"])) {
	$gallery = strip_tags(trim(stripslashes(htmlspecialchars($_GET["g"], ENT_QUOTES, 'UTF-8'))));
	$gallery = str_replace("/","", $gallery);
	$gallery = str_replace("\\","", $gallery);	
}

$opFile = ROOTPATH . "/data/img/gallery/". $gallery ."/gallery.txt";

if (file_exists($opFile)) {
    $fp   = fopen($opFile,"r");
    $data = @fread($fp, filesize($opFile));
    fclose($fp);

    $line        = explode("\n", $data);
    $no_of_posts = count($line)-1;
 
 	$image = sortImages($line);
 
    for ($i = 0; $i < $no_of_posts + 1; $i++) {

         if ($image[$i][1] == $gallery) {
             echo '<li><img data-fade="2000"  src="http://'. $_SERVER['HTTP_HOST'] .'/'. $pulse_dir .'/data/img/gallery/'. $gallery .'/'. $image[$i][2] .'" alt="'. $image[$i][3] .'" /></li>' . "\n";
             if (!empty($image[$i][3])) {
           	     echo ''. $image[$i][3] .'' . "";           	 	
            }
	    }
    }
} 
unset($image, $i, $test_line, $line, $data, $opFile, $gallery, $_GET["g"], $no_of_posts, $key, $val, $b, $xyn, $v);
?>