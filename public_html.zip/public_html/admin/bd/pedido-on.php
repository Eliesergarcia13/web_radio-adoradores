
 <section id="contact">
 <form action="pedido.php" method="post">
                                  <h5>Nome:</h5>
                                  <input type="text" id="nome" name="nome" required />

                                   <h5>E-mail:</h5>
                                   <input type="text" name="email" id="email" required/>
                          
                                  <h5>Seu Pedido:</h5>
                                  <textarea name="pedido" id="message" required></textarea>
                              <br/>
                       <center>
                          <button id="submit1" type="submit" name="enviar">Enviar</button>
                          </center>
                      </form>
                      <div id="valid-issue" style="display:none;"> Por favor, forneça informações válidas</div>   
 </section>
