<?php
$ip_stream = "fluoz.zeno.fm:80/0f5q094z24zuv/source";
$port_stream = "80";
$prot_stream = "/live";

?>