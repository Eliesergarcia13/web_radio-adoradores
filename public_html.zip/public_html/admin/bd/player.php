<?php
$back_player = "#0080c0";
$nome_stream = "Rádio Semeadores";
$pos_player = "";
$player_on = "1";



?>