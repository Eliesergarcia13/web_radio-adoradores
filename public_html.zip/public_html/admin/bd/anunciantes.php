<?php

$anun_nome1 = "ANUNCIE AQUI !!";
$anun_link1 = "#";
$anun_nome2 = "ANUNCIE AQUI !!";
$anun_link2 = "#";
$anun_nome3 = "ANUNCIE AQUI !!";
$anun_link3 = "#";
$anun_nome4 = "ANUNCIE AQUI !!";
$anun_link4 = "#";
$anun_nome5 = "ANUNCIE AQUI !!";
$anun_link5 = "#";
$anun_nome6 = "ANUNCIE AQUI !!";
$anun_link6 = "#";
$anun_nome7 = "ANUNCIE AQUI !!";
$anun_link7 = "#";
$anun_nome8 = "ANUNCIE AQUI !!";
$anun_link8 = "#";

?>