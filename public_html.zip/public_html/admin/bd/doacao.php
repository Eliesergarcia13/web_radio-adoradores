<?php
$doacao = "1";
$email_pagseguro = "eliesergarcia13@gmail.com";
$msg_doacao = "Ajude a Rádio se manter no ar";
?>