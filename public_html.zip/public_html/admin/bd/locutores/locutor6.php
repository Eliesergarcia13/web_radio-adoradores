<center>
<br/>
	<img src="admin/assets/img/locutores/locutor6.png" /></center>
		<div class="event-feed">
			<h5><?php echo $locutor6_nome;?></h5>
			<p><?php echo $programa6_nome;?></p>
			</div>

