<center>
<br/>
	<img src="admin/assets/img/locutores/locutor7.png" /></center>
		<div class="event-feed">
			<h5><?php echo $locutor7_nome;?></h5>
			<p><?php echo $programa7_nome;?></p>
			</div>
