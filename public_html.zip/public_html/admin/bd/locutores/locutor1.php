<center>
<br/>
	<img src="admin/assets/img/locutores/padrao.png" /></center>
		<div class="event-feed">
			<h5><?php echo $locutor1_nome;?></h5>
			<p><?php echo $programa1_nome;?></p>
		</div>

