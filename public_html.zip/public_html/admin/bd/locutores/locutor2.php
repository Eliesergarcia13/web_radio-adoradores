<center>
<br/>
	<img src="admin/assets/img/locutores/locutor2.png" /></center>
		<div class="event-feed">
			<h5><?php echo $locutor2_nome;?></h5>
			<p><?php echo $programa2_nome;?></p>
		</div>
