<center>
<br/>
	<img src="admin/assets/img/locutores/locutor3.png" /></center>
		<div class="event-feed">
			<h5><?php echo $locutor3_nome;?></h5>
			<p><?php echo $programa3_nome;?></p>
		</div>
		
