<center>
<br/>
	<img src="admin/assets/img/locutores/locutor5.png" /></center>
		<div class="event-feed">
			<h5><?php echo $locutor5_nome;?></h5>
			<p><?php echo $programa5_nome;?></p>
			</div>

