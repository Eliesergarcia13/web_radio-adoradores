<center>
<br/>
	<img src="admin/assets/img/locutores/locutor8.png" /></center>
		<div class="event-feed">
			<h5><?php echo $locutor8_nome;?></h5>
			<p><?php echo $programa8_nome;?></p>
			</div>

