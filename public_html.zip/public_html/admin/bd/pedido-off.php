<center>
<p><?php echo $msg_offline; ?></p>
</center>