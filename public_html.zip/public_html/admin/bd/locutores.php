<?php
$locutor_select = "locutor2.php";
$pedido_select = "pedido-on.php";
$msg_offline = "No momento todos os nossos apresentadores estão offline, tente novamente mais tarde, obrigado!";
$locutor1_nome = "AutoDJ";
$programa1_nome = "Gospel Mix";
$locutor2_nome = "Jose Paulo";
$programa2_nome = "Semeando a Palavra";
$locutor3_nome = "AutoDJ 3";
$programa3_nome = "Gospel Mix";
$locutor4_nome = "AutoDJ 4";
$programa4_nome = "Gospel Mix";
$locutor5_nome = "AutoDJ 5";
$programa5_nome = "Gospel Mix";
$locutor6_nome = "AutoDJ 6";
$programa6_nome = "Gospel Mix";
$locutor7_nome = "AutoDJ 7";
$programa7_nome = "Gospel Mix";
$locutor8_nome = "AutoDJ 8";
$programa8_nome = "Gospel Mix";
$locutor9_nome = "AutoDJ 9";
$programa9_nome = "Gospel Mix";
$locutor10_nome = "AutoDJ 10";
$programa10_nome = "Gospel Mix";
?>