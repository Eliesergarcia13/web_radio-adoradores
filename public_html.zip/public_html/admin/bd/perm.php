
<?php include ("perfil.php");  ?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">
  <h2>Web Rádio Menu</h2>
  <ul class="nav nav-tabs">
    <li class="active"><a data-toggle="tab" href="#home">Home</a></li>
    <li><a data-toggle="tab" href="#home2">Menu 2</a></li>
     <li><a data-toggle="tab" href="#menu3"></a></li>
  </ul>

  <div class="tab-content">
    <div id="home" class="tab-pane fade in active">
      <p></p>
    </div>

      <div class="tab-content">
    <div id="home2" class="tab-pane fade in active">
      <p></p>
    </div>
    <div id="menu3" class="tab-pane fade">
      <p style="color:#fff;">a7645a6dfdB<?php echo $pulse_pass; ?>Bf5fg544sd4<p>
    </div>
  </div>
</div>

</body>
</html>
