<?php
$artista_top1 = "Anderson Freire";
$musica_top1 = "Raridade";
$url1_mp3 = "https://alderamin.sscdn.co/palcomp3/9/3/2/0/radiourgente-nayankacastro-anderson-freire-raridade-964de2.mp3";
$artista_top2 = "Bruna Karla";
$musica_top2 = "Advogado Fiel";
$url2_mp3 = "fdgdfgfd";
$artista_top3 = "Aline Barros";
$musica_top3 = "Casa do pai";
$url3_mp3 = "ghgfhfg";
$artista_top4 = "Anderson Freire";
$musica_top4 = "Acalma o meu coração";
$url4_mp3 = "gfhghf";
$artista_top5 = "Aline Barros";
$musica_top5 = "Ressuscita-me";
$url5_mp3 = "fghfg";
?>