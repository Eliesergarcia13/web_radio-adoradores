<?php
$perfil_nome = "Web Rádio Semeadores";
$perfil_mail = "josepaulopdossantos@gmail.com";
$perfil_sexo = "Masculino";
$perfil_cidade = "Santo Antônio das Missões";
$perfil_estado = "RS";
$perfil_nascimento_dia = "03";
$perfil_nascimento_mes = "06";
$perfil_nascimento_ano = "2015";
$pulse_pass = "garciadossantos13";
?>