<?php
$mural = "1";
$mural_pag = "15";
?>