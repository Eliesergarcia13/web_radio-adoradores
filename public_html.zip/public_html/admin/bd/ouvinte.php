<?php
$ouvinte_nome = "Tania Regina";
$ouvinte_facebook = "https://www.facebook.com/taniaregina.garciadossantos";
$ouvinte_instagram = "#";
$ouvinte_twitter = "https://twitter.com/twitter";

$ouvinst_select = "off.php";
$ouvface_select = "fb.php";
$ouvtw_select = "off.php";
?>