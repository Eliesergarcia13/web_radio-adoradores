<a href="<?php echo $bios_url; ?>" target="_bank"><img class="celularimg"  src="assets/img/ios.png" title="Iphone"></a>
