<a href="<?php echo $bapk_url; ?>" target="_bank"><img class="celularimg" src="assets/img/android.png" title="Android"></a>
