<?php include ("../locutores.php");  ?>
<head> <meta http-equiv="refresh" content="30;URL=/admin/bd/locutores-player/<?php echo $locutor_select; ?>"> </head> 
<img src="/admin/assets/img/locutores/locutor4.png" width="32px" height="32px" />
<marquee style="position: absolute; margin-top: 5px; color:#000; margin-left: 7px;"  width=250  direction=left> 
<span ><b>Apresentador:</b> <?php echo $locutor4_nome;?>  /   <b>Programa:</b> <?php echo $programa4_nome;?></span></marquee>


<?php include ("../locutores.php");  ?>
<head><link href='http://fonts.googleapis.com/css?family=Oswald:400,700,300' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Roboto:400,400italic,700' rel='stylesheet' type='text/css'> <meta http-equiv="refresh" content="30;URL=/admin/bd/locutores-player/<?php echo $locutor_select; ?>"> </head> 
<img src="/admin/assets/img/locutores/locutor4.png" width="38px" height="38px" />
<marquee style="position: absolute; margin-top: 15px; color:#fff; margin-left: 7px;"  width=250  direction=left>
<span style="font-family: 'Oswald', sans-serif; font-size:15px"><b>Apresentador:</b> <?php echo $locutor4_nome;?>  /   <b>Programa:</b> <?php echo $programa4_nome;?></span></marquee>