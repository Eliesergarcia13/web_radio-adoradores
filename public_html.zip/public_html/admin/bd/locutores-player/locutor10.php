<?php include ("../locutores.php");  ?>
<head><link href='http://fonts.googleapis.com/css?family=Oswald:400,700,300' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Roboto:400,400italic,700' rel='stylesheet' type='text/css'> <meta http-equiv="refresh" content="30;URL=/admin/bd/locutores-player/<?php echo $locutor_select; ?>"> </head> 
<img src="/admin/assets/img/locutores/locutor10.png" width="38px" height="38px" />
<marquee style="position: absolute; margin-top: 15px; color:#fff; margin-left: 7px;"  width=250  direction=left>
<span style="font-family: 'Oswald', sans-serif; font-size:15px"><b>Apresentador:</b> <?php echo $locutor10_nome;?>  /   <b>Programa:</b> <?php echo $programa10_nome;?></span></marquee>