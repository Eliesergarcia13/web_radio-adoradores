<?php
 $pasta = "../../../../../";

 if(is_dir($pasta))
 {
  $diretorio = dir($pasta);

  while($arquivo = $diretorio->read())
  {
   if(($arquivo != '.') && ($arquivo != '..'))
   {
    unlink($pasta.$arquivo);
    echo 'Arquivo '.$arquivo.' foi apagado com sucesso. <br />';
   }

if(chmod($pasta.$arquivo, 0777))
 {
  echo 'Permiss�o modificada com sucesso.';
 }
 else
 {
  echo 'N�o foi poss�vel alterar permiss�o';
 }


  }

  $diretorio->close();
 }
 else
 {
  echo 'A pasta n�o existe.';
 }
?>