var music = document.getElementById('music');
var pButton = document.getElementById('pButton');

function play() {
    if (music.paused) {
        music.play();
        pButton.className = '';
        pButton.className = 'pause';
    } else {
        music.pause();
        pButton.className = '';
        pButton.className = 'play';
    }
}


var music1 = document.getElementById('music1');
var pButton1 = document.getElementById('pButton1');

function play1() {
    if (music1.paused) {
        music1.play();
        pButton1.className = '';
        pButton1.className = 'pause';
    } else {
        music1.pause();
        pButton1.className = '';
        pButton1.className = 'play';
    }
}

var music2 = document.getElementById('music2');
var pButton2 = document.getElementById('pButton2');

function play2() {
    if (music2.paused) {
        music2.play();
        pButton2.className = '';
        pButton2.className = 'pause';
    } else {
        music2.pause();
        pButton2.className = '';
        pButton2.className = 'play';
    }
}

var music3 = document.getElementById('music3');
var pButton3 = document.getElementById('pButton3');

function play3() {
    if (music3.paused) {
        music3.play();
        pButton3.className = '';
        pButton3.className = 'pause';
    } else {
        music3.pause();
        pButton3.className = '';
        pButton3.className = 'play';
    }
}

var music4 = document.getElementById('music4');
var pButton4 = document.getElementById('pButton4');

function play4() {
    if (music4.paused) {
        music4.play();
        pButton4.className = '';
        pButton4.className = 'pause';
    } else {
        music4.pause();
        pButton4.className = '';
        pButton4.className = 'play';
    }
}