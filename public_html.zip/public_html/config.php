<?php
$pulse_dir = "admin";
$page_title = "Web Rádio Semeadores - A estação do seu rádio";
$page_desc = "Web Rádio Semeadores - A estação do seu rádio";
$page_words = "Rádio, online, web rádio, notícias, músicas, blog, eventos, vídeo, ao vivo.";
$height = "270";
$width = "270";
$blog_url = "blog.php";
$menu_home = "Home";
$menu_sobre = "Sobre";
$menu_noticias = "Notícias";
$menu_mural = "Recados";
$menu_programacao = "Programação";
$menu_eventos = "Eventos";
$menu_fotos = "Fotos";
$menu_videos = "Vídeos";
$menu_equipe = "Equipe";
$menu_contato = "Contato";
$youtube_url = "#";
$analytics_id = "";
$per_page = "3";
$blog_comments = true;
$blog_capcha = false;
$date_format = "d/m/Y";
$email_contact = "josepaulopdossantos@gmail.com";
$nub_whatsapp = "(55) 9 9670-7928";
$facebook_url = "https://m.facebook.com/josepaulo.pinto.58";
$twitter_url = "https://twitter.com";
$google_url = "https://plus.google.com";
$linkedin_url = "#";
$pinterest_url = "#";
$instagram_url = "#";
$flickr_url = "#";
$pulse_lang = "PT_BR";
$custom_fieldname1 = "";
$custom_fieldname2 = "";
$formcap = "1";
$corsite = "padrao";

$apk_url = "https://play.google.com/store/apps/details?id=seuid";
$ios_url = "https://play.google.com/store/apps/details?id=seuid";
$apk_select = "apk.php";
$ios_select = "ios.php";


$bapk_select = "android.php";
$bios_select = "iphone.php";
$bwin_select = "windows.php";
$bblack_select = "blackberry.php";

$bapk_url = "https://play.google.com/store/apps/details?id=seuid";
$bios_url = "https://play.google.com/store/apps/details?id=seuid";
$bwin_url = "https://play.google.com/store/apps/details?id=seuid";
$bblack_url = "https://play.google.com/store/apps/details?id=seuid";


?>